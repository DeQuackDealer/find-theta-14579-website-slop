import { useEffect, useState } from "react";
import ThetaGlyph from "./ThetaGlyph";
import { cn } from "../utils/cn";

type Route = "home" | "fleet" | "gallery" | "updates" | "sponsors";

const links: { label: string; route: Route; hash: string }[] = [
  { label: "Fleet", route: "fleet", hash: "#/fleet" },
  { label: "Gallery", route: "gallery", hash: "#/gallery" },
  { label: "Updates", route: "updates", hash: "#/updates" },
  { label: "Sponsors", route: "sponsors", hash: "#/sponsors" },
];

export default function Nav({ current }: { current: Route }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [current]);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-200",
        scrolled
          ? "bg-bone-50/90 backdrop-blur border-b border-ink-900/10"
          : "bg-transparent border-b border-transparent"
      )}
    >
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-5 py-4 sm:px-8 lg:px-12">
        {/* Logo */}
        <a
          href="#/"
          aria-label="Find Theta — Home"
          className="group flex items-center gap-3"
        >
          <span className="grid h-9 w-9 place-items-center bg-ink-900 text-bone-50 transition-transform group-hover:rotate-[12deg]">
            <ThetaGlyph size={22} className="text-bone-50" />
          </span>
          <div className="hidden sm:flex flex-col leading-none">
            <span className="font-display text-[15px] tracking-tight text-ink-900">
              FIND <span className="text-spark">TH</span>ETA
            </span>
            <span className="mt-1 font-mono text-[10px] font-medium uppercase tracking-[0.2em] text-ink-500">
              FTC Team // 14579
            </span>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1" aria-label="Primary">
          {links.map((l) => {
            const active = current === l.route;
            return (
              <a
                key={l.route}
                href={l.hash}
                className={cn(
                  "relative px-3 py-2 font-mono text-xs font-medium uppercase tracking-wider transition-colors",
                  active ? "text-ink-900" : "text-ink-500 hover:text-ink-900"
                )}
              >
                {l.label}
                {active && (
                  <span className="absolute inset-x-3 -bottom-0.5 h-[2px] bg-spark" />
                )}
              </a>
            );
          })}
          <a
            href="#/sponsors#contact"
            className="ml-3 inline-flex items-center gap-2 bg-ink-900 px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 transition-colors hover:bg-spark"
          >
            Back us
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
              <path d="M1 6h10M7 2l4 4-4 4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
            </svg>
          </a>
        </nav>

        {/* Mobile toggle */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-label="Toggle menu"
          className="md:hidden relative h-10 w-10 border border-ink-900/20 bg-bone-50 text-ink-900"
        >
          <span
            className={cn(
              "absolute left-2 right-2 h-[2px] bg-current transition-all",
              open ? "top-1/2 -translate-y-1/2 rotate-45" : "top-[14px]"
            )}
          />
          <span
            className={cn(
              "absolute left-2 right-2 h-[2px] bg-current transition-all",
              open ? "opacity-0" : "top-1/2 -translate-y-1/2"
            )}
          />
          <span
            className={cn(
              "absolute left-2 right-2 h-[2px] bg-current transition-all",
              open ? "bottom-1/2 translate-y-1/2 -rotate-45" : "bottom-[14px]"
            )}
          />
        </button>
      </div>

      {/* Mobile panel */}
      <div
        className={cn(
          "md:hidden overflow-hidden border-t border-ink-900/10 bg-bone-50 transition-[max-height] duration-300",
          open ? "max-h-96" : "max-h-0"
        )}
      >
        <nav className="flex flex-col px-5 py-3" aria-label="Mobile">
          {links.map((l) => {
            const active = current === l.route;
            return (
              <a
                key={l.route}
                href={l.hash}
                className={cn(
                  "flex items-center justify-between border-b border-ink-900/10 py-3 font-mono text-sm font-medium uppercase tracking-wider",
                  active ? "text-spark" : "text-ink-800"
                )}
              >
                <span>{l.label}</span>
                <span className="font-mono text-[10px] text-ink-400">
                  0{links.indexOf(l) + 1}
                </span>
              </a>
            );
          })}
          <a
            href="#/sponsors#contact"
            className="mt-3 inline-flex items-center justify-center gap-2 bg-ink-900 px-4 py-3 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50"
          >
            Back the team
          </a>
        </nav>
      </div>
    </header>
  );
}
