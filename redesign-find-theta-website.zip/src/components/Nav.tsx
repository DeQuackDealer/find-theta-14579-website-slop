import { useEffect, useState } from 'react';
import { cn } from '../utils/cn';
import { ThetaMark, MenuIcon, CloseIcon } from './Icons';

type NavProps = {
  currentPath: string;
  onNavigate: (path: string) => void;
};

const links = [
  { label: 'Home', path: '/' },
  { label: 'Fleet', path: '/fleet' },
  { label: 'Gallery', path: '/gallery' },
  { label: 'Updates', path: '/updates' },
  { label: 'Sponsors', path: '/sponsors' },
];

export function Nav({ currentPath, onNavigate }: NavProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [currentPath]);

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
          scrolled
            ? 'bg-ink/85 backdrop-blur-md border-b border-line'
            : 'bg-transparent border-b border-transparent'
        )}
      >
        <nav className="max-w-[1400px] mx-auto px-5 md:px-8 h-16 md:h-20 flex items-center justify-between">
          <button
            onClick={() => onNavigate('/')}
            className="group flex items-center gap-3 text-left"
            aria-label="Find Theta home"
          >
            <span className="text-amber">
              <ThetaMark className="w-8 h-8 transition-transform group-hover:rotate-45 duration-500" />
            </span>
            <span className="flex flex-col leading-none">
              <span className="font-mono text-[10px] tracking-[0.2em] text-ash uppercase mb-0.5">FTC 14579</span>
              <span className="font-sans font-semibold text-base md:text-lg tracking-tight text-chalk">
                Find Theta
              </span>
            </span>
          </button>

          {/* Desktop */}
          <ul className="hidden md:flex items-center gap-0">
            {links.map((l) => {
              const active = currentPath === l.path;
              return (
                <li key={l.path}>
                  <button
                    onClick={() => onNavigate(l.path)}
                    className={cn(
                      'relative px-5 h-10 font-mono text-[12px] uppercase tracking-[0.18em] transition-colors',
                      active ? 'text-chalk' : 'text-ash hover:text-chalk'
                    )}
                  >
                    <span className="relative z-10">{l.label}</span>
                    {active && (
                      <span className="absolute inset-0 border-b-2 border-amber" />
                    )}
                  </button>
                </li>
              );
            })}
          </ul>

          <div className="hidden md:flex items-center gap-3">
            <span className="flex items-center gap-2 font-mono text-[10px] text-ash uppercase tracking-[0.18em]">
              <span className="w-1.5 h-1.5 rounded-full bg-signal animate-[pulseDot_2s_ease-in-out_infinite]" />
              <span>Build Season</span>
            </span>
          </div>

          {/* Mobile trigger */}
          <button
            onClick={() => setMobileOpen((v) => !v)}
            className="md:hidden text-chalk p-2 -mr-2"
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileOpen ? <CloseIcon className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
          </button>
        </nav>
      </header>

      {/* Mobile menu */}
      <div
        className={cn(
          'fixed inset-0 z-40 md:hidden transition-opacity duration-300',
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
      >
        <div className="absolute inset-0 bg-ink/95 backdrop-blur-lg" onClick={() => setMobileOpen(false)} />
        <div className="relative pt-24 px-6 h-full flex flex-col">
          <ul className="space-y-1">
            {links.map((l, i) => {
              const active = currentPath === l.path;
              return (
                <li
                  key={l.path}
                  style={{ animationDelay: `${i * 60}ms` }}
                  className={cn(mobileOpen && 'animate-[slideIn_0.4s_ease-out_both]')}
                >
                  <button
                    onClick={() => onNavigate(l.path)}
                    className={cn(
                      'w-full flex items-baseline gap-4 py-4 border-b border-line text-left',
                      active ? 'text-amber' : 'text-chalk'
                    )}
                  >
                    <span className="font-mono text-xs text-ash w-8">
                      0{i + 1}
                    </span>
                    <span className="font-sans text-2xl font-medium tracking-tight">
                      {l.label}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
          <div className="mt-auto pb-8 font-mono text-[11px] text-ash leading-relaxed">
            <div className="flex items-center gap-2 mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-signal animate-[pulseDot_2s_ease-in-out_infinite]" />
              Build Season Active
            </div>
            <div>FTC Team 14579</div>
          </div>
        </div>
      </div>
    </>
  );
}
