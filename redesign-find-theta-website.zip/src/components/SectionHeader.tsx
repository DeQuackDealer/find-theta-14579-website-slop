import { cn } from "../utils/cn";

export default function SectionHeader({
  number,
  kicker,
  title,
  subtitle,
  align = "left",
  className,
}: {
  number?: string;
  kicker?: string;
  title: React.ReactNode;
  subtitle?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-4",
        align === "center" ? "items-center text-center" : "items-start",
        className
      )}
    >
      <div className="flex items-center gap-3">
        {number && (
          <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-spark">
            {number}
          </span>
        )}
        {kicker && (
          <span className="label-stencil text-ink-500">{kicker}</span>
        )}
      </div>
      <h2 className="font-display text-[clamp(2rem,5vw,3.75rem)] leading-[0.95] tracking-tight text-ink-900">
        {title}
      </h2>
      {subtitle && (
        <p className={cn("max-w-2xl text-[15px] leading-relaxed text-ink-600",
          align === "center" && "mx-auto"
        )}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
