import { cn } from "../utils/cn";

/**
 * The Find Theta mark: a bold uppercase Θ with a measuring tick / ibis-beak accent.
 * Used as logomark, section divider, hero element.
 */
export default function ThetaGlyph({
  size = 40,
  className,
  accent = false,
  animated = false,
}: {
  size?: number;
  className?: string;
  accent?: boolean;
  animated?: boolean;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn(className)}
      aria-hidden="true"
    >
      {/* Outer Θ circle */}
      <circle
        cx="32"
        cy="32"
        r="24"
        stroke="currentColor"
        strokeWidth="3.5"
        className={animated ? "stroke-current" : ""}
      />
      {/* Horizontal bar with extended tick (ibis beak / measurement tick) */}
      <line
        x1="8"
        y1="32"
        x2={accent ? "56" : "56"}
        y2="32"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="square"
      />
      {/* Tick mark at the measurement point */}
      {accent && (
        <>
          <line
            x1="46"
            y1="26"
            x2="46"
            y2="38"
            stroke="var(--color-spark)"
            strokeWidth="3"
            strokeLinecap="square"
          />
          <circle cx="46" cy="32" r="2.25" fill="var(--color-spark)" />
        </>
      )}
      {/* Subtle tick marks around circle for "precision instrument" feel */}
      <g stroke="currentColor" strokeWidth="1.5" opacity="0.4">
        <line x1="32" y1="4" x2="32" y2="9" />
        <line x1="32" y1="55" x2="32" y2="60" />
      </g>
    </svg>
  );
}
