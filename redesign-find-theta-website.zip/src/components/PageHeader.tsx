import { ReactNode } from 'react';

type PageHeaderProps = {
  eyebrow: string;
  title: ReactNode;
  subtitle?: string;
  meta?: Array<{ label: string; value: string }>;
};

export function PageHeader({ eyebrow, title, subtitle, meta }: PageHeaderProps) {
  return (
    <section className="relative pt-32 md:pt-40 pb-12 md:pb-16 border-b border-line overflow-hidden">
      <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
      <div
        className="absolute left-1/2 top-0 -translate-x-1/2 w-[800px] h-[400px] pointer-events-none opacity-30"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(255,107,26,0.18), transparent 60%)',
        }}
      />
      <div className="relative max-w-[1400px] mx-auto px-5 md:px-8">
        <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-6 flex items-center gap-3">
          <span className="inline-block w-8 h-px bg-amber" />
          {eyebrow}
        </div>
        <h1 className="font-sans font-semibold text-4xl md:text-6xl lg:text-7xl tracking-tight text-chalk leading-[1.02] max-w-4xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-6 md:mt-8 text-ash text-lg md:text-xl max-w-2xl leading-relaxed">
            {subtitle}
          </p>
        )}
        {meta && (
          <div className="mt-10 grid grid-cols-2 md:grid-cols-4 border-t border-line">
            {meta.map((m, i) => (
              <div
                key={i}
                className={
                  'py-4 md:py-5 px-0 md:px-4 border-b border-line ' +
                  (i % 2 === 0 ? 'md:border-r' : '') +
                  ' md:border-b-0 ' +
                  (i < 2 ? 'border-r' : '')
                }
              >
                <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-ash mb-1">{m.label}</div>
                <div className="font-sans text-base md:text-lg text-chalk">{m.value}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
