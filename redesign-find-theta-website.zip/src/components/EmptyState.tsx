import { ReactNode } from 'react';
import { cn } from '../utils/cn';

type EmptyStateProps = {
  tag: string;
  title: string;
  description: string;
  children?: ReactNode;
  className?: string;
};

export function EmptyState({ tag, title, description, children, className }: EmptyStateProps) {
  return (
    <div className={cn('relative border border-line bg-ink-2 p-8 md:p-12', className)}>
      <span className="corner-ticks absolute inset-0 pointer-events-none" />
      <div className="flex items-start gap-4 md:gap-6">
        <div className="hidden md:flex flex-col items-center pt-1">
          <div className="font-mono text-[10px] text-amber tracking-[0.2em] uppercase rotate-90 origin-center mt-8">
            {tag}
          </div>
        </div>
        <div className="md:border-l md:border-line md:pl-8 flex-1">
          <div className="flex items-center gap-3 mb-4 md:hidden">
            <div className="w-2 h-2 bg-amber animate-[pulseDot_2s_ease-in-out_infinite]" />
            <span className="font-mono text-[10px] text-amber tracking-[0.2em] uppercase">
              {tag}
            </span>
          </div>
          <div className="flex items-center gap-3 mb-5 hidden md:flex">
            <div className="w-2 h-2 bg-amber animate-[pulseDot_2s_ease-in-out_infinite]" />
            <span className="font-mono text-[10px] text-ash tracking-[0.2em] uppercase">
              Pending data · this section is under construction
            </span>
          </div>
          <h3 className="font-sans text-2xl md:text-4xl font-semibold tracking-tight text-chalk mb-3">
            {title}
          </h3>
          <p className="text-ash leading-relaxed max-w-2xl">
            {description}
          </p>
          {children && <div className="mt-6">{children}</div>}
        </div>
      </div>
    </div>
  );
}
