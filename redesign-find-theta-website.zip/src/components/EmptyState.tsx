import { cn } from "../utils/cn";

export default function EmptyState({
  label,
  title,
  description,
  action,
  icon,
  className,
}: {
  label?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden border border-dashed border-ink-900/20 bg-bone-100/40 p-8 sm:p-12",
        className
      )}
    >
      <div className="grid-bg-fine absolute inset-0 opacity-60" aria-hidden />
      {/* Corner ticks like a technical drawing */}
      <CornerTicks />
      <div className="relative flex flex-col items-start gap-4">
        <div className="flex items-center gap-3">
          {icon ?? (
            <span className="grid h-8 w-8 place-items-center border border-ink-900/20 bg-bone-50">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
                <circle cx="7" cy="7" r="5.25" stroke="currentColor" strokeWidth="1.25" />
                <path d="M7 4v3l2 1.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="square" />
              </svg>
            </span>
          )}
          {label && (
            <span className="label-stencil text-ink-500">{label}</span>
          )}
        </div>
        <h3 className="font-display text-2xl leading-tight tracking-tight text-ink-900">
          {title}
        </h3>
        {description && (
          <p className="max-w-xl text-sm leading-relaxed text-ink-600">
            {description}
          </p>
        )}
        {action && <div className="mt-2">{action}</div>}
      </div>
    </div>
  );
}

function CornerTicks() {
  const cls = "absolute h-3 w-3 border-spark";
  return (
    <>
      <span className={cn(cls, "-top-px -left-px border-t border-l")} />
      <span className={cn(cls, "-top-px -right-px border-t border-r")} />
      <span className={cn(cls, "-bottom-px -left-px border-b border-l")} />
      <span className={cn(cls, "-bottom-px -right-px border-b border-r")} />
    </>
  );
}
