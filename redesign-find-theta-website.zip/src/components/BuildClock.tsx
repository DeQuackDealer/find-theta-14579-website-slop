import { useEffect, useState } from "react";

/**
 * A live-updating elapsed-time clock styled like a telemetry readout.
 * Counts up from the kickoff of build season (or just shows "active" with
 * a running second counter as a heartbeat).
 */
export default function BuildClock() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // We don't have an authoritative kickoff timestamp on the source site,
  // so we show current time as a running build-season clock readout
  // formatted like field telemetry.
  const pad = (n: number, w = 2) => String(n).padStart(w, "0");
  const hh = pad(now.getHours());
  const mm = pad(now.getMinutes());
  const ss = pad(now.getSeconds());

  return (
    <div className="inline-flex items-center gap-3 rounded-none border border-ink-900/15 bg-bone-100/60 px-3 py-1.5 font-mono text-[11px] font-medium uppercase tracking-widest text-ink-700">
      <span className="relative flex h-2 w-2 items-center justify-center">
        <span className="absolute inset-0 rounded-full bg-spark pulse-ring" />
        <span className="h-1.5 w-1.5 rounded-full bg-spark" />
      </span>
      <span>Build season active</span>
      <span className="h-3 w-px bg-ink-900/20" aria-hidden />
      <span className="tabular-nums text-ink-900">
        {hh}:{mm}:
        <span className="inline-block min-w-[1.5em] text-spark">{ss}</span>
      </span>
    </div>
  );
}
