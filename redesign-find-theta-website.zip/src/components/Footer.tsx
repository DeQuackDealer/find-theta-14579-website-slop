import { ThetaMark, Arrow } from './Icons';

type FooterProps = {
  onNavigate: (path: string) => void;
};

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="relative bg-ink-2 border-t border-line mt-0">
      {/* CTA band */}
      <div className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-24 grid md:grid-cols-12 gap-8 md:gap-12 items-center">
          <div className="md:col-span-7">
            <div className="font-mono text-[11px] uppercase tracking-[0.22em] text-amber mb-4">
              // Contact
            </div>
            <h2 className="font-sans text-3xl md:text-5xl font-semibold tracking-tight text-chalk leading-[1.05]">
              Want to support a team
              <br />
              that builds, breaks, <em className="text-amber not-italic">and ships?</em>
            </h2>
            <p className="mt-5 text-ash max-w-xl text-base md:text-lg leading-relaxed">
              Sponsorships, mentoring, media, or just to say hi — our inbox is open.
              Every part, tool, and trip to competition is funded through people who believe in what we're doing.
            </p>
          </div>
          <div className="md:col-span-5 flex flex-col gap-3 md:items-end">
            <a
              href="mailto:contact@findtheta.org"
              className="group inline-flex items-center gap-3 bg-amber text-ink font-mono uppercase tracking-[0.15em] text-sm px-6 py-4 hover:bg-amber-bright transition-colors w-full md:w-auto justify-between md:justify-start"
            >
              <span>contact@findtheta.org</span>
              <Arrow className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </a>
            <button
              onClick={() => onNavigate('/sponsors')}
              className="group inline-flex items-center gap-3 border border-line text-chalk font-mono uppercase tracking-[0.15em] text-sm px-6 py-4 hover:border-amber hover:text-amber transition-colors w-full md:w-auto justify-between md:justify-start"
            >
              <span>Become a sponsor</span>
              <Arrow className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom footer */}
      <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-10">
        <div className="grid md:grid-cols-12 gap-8">
          <div className="md:col-span-4">
            <div className="flex items-center gap-3 mb-4">
              <ThetaMark className="w-8 h-8 text-amber" />
              <div className="flex flex-col leading-none">
                <span className="font-mono text-[10px] tracking-[0.2em] text-ash uppercase mb-0.5">FTC 14579</span>
                <span className="font-sans font-semibold text-lg text-chalk">Find Theta</span>
              </div>
            </div>
            <p className="text-ash text-sm leading-relaxed max-w-xs">
              A student-run FIRST Tech Challenge team. We design, build, and program
              competition robots with the precision of the ibis.
            </p>
          </div>

          <div className="md:col-span-3 md:col-start-6">
            <h4 className="font-mono text-[11px] uppercase tracking-[0.2em] text-ash mb-4">Sitemap</h4>
            <ul className="space-y-2 font-sans">
              {[
                { label: 'Home', path: '/' },
                { label: 'Fleet', path: '/fleet' },
                { label: 'Gallery', path: '/gallery' },
                { label: 'Updates', path: '/updates' },
                { label: 'Sponsors', path: '/sponsors' },
              ].map((l) => (
                <li key={l.path}>
                  <button
                    onClick={() => onNavigate(l.path)}
                    className="text-chalk/80 hover:text-amber text-sm transition-colors"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <h4 className="font-mono text-[11px] uppercase tracking-[0.2em] text-ash mb-4">Season</h4>
            <ul className="space-y-2 font-mono text-xs text-chalk/70">
              <li className="flex justify-between"><span>Status</span><span className="text-signal">Active</span></li>
              <li className="flex justify-between"><span>Team #</span><span>14579</span></li>
              <li className="flex justify-between"><span>Region</span><span>FTC</span></li>
              <li className="flex justify-between"><span>Year</span><span>2025–2026</span></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-line flex flex-col md:flex-row justify-between gap-3 font-mono text-[11px] text-ash">
          <div>© 2026 Find Theta · FTC Team 14579</div>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-signal animate-[pulseDot_2s_ease-in-out_infinite]" />
            All systems nominal
          </div>
        </div>
      </div>
    </footer>
  );
}
