import ThetaGlyph from "./ThetaGlyph";

export default function Footer() {
  return (
    <footer className="relative border-t-2 border-ink-900 bg-ink-900 text-bone-100">
      <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8 lg:px-12">
        <div className="grid gap-10 md:grid-cols-12">
          {/* Left: mark + blurb */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center border border-bone-50/20">
                <ThetaGlyph size={22} className="text-bone-50" />
              </span>
              <div>
                <div className="font-display text-lg tracking-tight text-bone-50">
                  FIND <span className="text-spark-bright">TH</span>ETA
                </div>
                <div className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.2em] text-bone-300/70">
                  FTC TEAM 14579
                </div>
              </div>
            </div>
            <p className="mt-6 max-w-md text-sm leading-relaxed text-bone-300/80">
              A student-run FIRST Tech Challenge team building competition
              robots with the precision of the ibis. Sharp-eyed, adaptable,
              never boxed in by one habitat.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <FooterChip label="Design" />
              <FooterChip label="Fabricate" />
              <FooterChip label="Program" />
              <FooterChip label="Compete" />
            </div>
          </div>

          {/* Middle: nav */}
          <div className="md:col-span-3">
            <div className="label-stencil !text-bone-300/60 mb-4">Navigate</div>
            <ul className="space-y-2 text-sm">
              <FooterLink href="#/" label="Home" />
              <FooterLink href="#/fleet" label="Fleet" />
              <FooterLink href="#/gallery" label="Gallery" />
              <FooterLink href="#/updates" label="Updates" />
              <FooterLink href="#/sponsors" label="Sponsors" />
            </ul>
          </div>

          {/* Right: contact */}
          <div id="contact" className="md:col-span-4">
            <div className="label-stencil !text-bone-300/60 mb-4">Contact</div>
            <p className="mb-4 text-sm leading-relaxed text-bone-300/80">
              Sponsorships, mentoring, media, or just to say hi — our inbox is
              open.
            </p>
            <a
              href="mailto:contact@findtheta.org"
              className="group inline-flex items-center gap-2 font-mono text-sm font-semibold text-bone-50 hover:text-spark-bright transition-colors"
            >
              contact@findtheta.org
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden className="transition-transform group-hover:translate-x-0.5">
                <path d="M2 12L12 2M12 2H4M12 2v8" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
              </svg>
            </a>
            <div className="mt-5 flex gap-2">
              {[
                { label: "Instagram", href: "#" },
                { label: "GitHub", href: "#" },
                { label: "YouTube", href: "#" },
                { label: "FIRST", href: "https://firstinspires.org" },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="border border-bone-50/20 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-bone-300/80 hover:border-spark-bright hover:text-spark-bright transition-colors"
                >
                  {s.label}
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-bone-50/10 pt-6 text-[11px] font-mono uppercase tracking-wider text-bone-300/60 sm:flex-row sm:items-center sm:justify-between">
          <div>© {new Date().getFullYear()} Find Theta — Team 14579</div>
          <div className="flex items-center gap-2">
            <span className="inline-block h-1.5 w-1.5 bg-spark-bright tick-dot" />
            <span>Build season active</span>
            <span className="mx-2 text-bone-300/30">/</span>
            <span>Made in the pits, on the road, and in the IDE.</span>
          </div>
        </div>
      </div>

      {/* Giant wordmark */}
      <div aria-hidden className="select-none overflow-hidden border-t border-bone-50/10">
        <div className="font-display text-[18vw] leading-none tracking-tighter text-bone-50/[0.04] whitespace-nowrap px-2">
          FINDTHETA
        </div>
      </div>
    </footer>
  );
}

function FooterChip({ label }: { label: string }) {
  return (
    <span className="border border-bone-50/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-bone-300/80">
      {label}
    </span>
  );
}

function FooterLink({ href, label }: { href: string; label: string }) {
  return (
    <li>
      <a
        href={href}
        className="group inline-flex items-center gap-2 text-bone-100 hover:text-spark-bright transition-colors"
      >
        <span className="inline-block h-px w-4 bg-bone-50/20 transition-all group-hover:w-6 group-hover:bg-spark-bright" />
        {label}
      </a>
    </li>
  );
}
