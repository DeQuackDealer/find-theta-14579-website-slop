import EmptyState from "../components/EmptyState";

export default function Gallery() {
  return (
    <>
      <section className="relative overflow-hidden border-b-2 border-ink-900 bg-ink-900 text-bone-50">
        <div className="grid-bg absolute inset-0 opacity-[0.08]" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.25em]">
            <span className="text-bone-300/70">Appendix</span>
            <span className="h-3 w-px bg-bone-300/30" />
            <span className="text-spark-bright">Gallery</span>
          </div>
          <h1 className="mt-6 font-display text-[clamp(2.5rem,8vw,6rem)] leading-[0.9] tracking-tight">
            Moments from <br />
            <span className="text-spark-bright">the pits &amp; the field.</span>
          </h1>
          <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-bone-300/80">
            Photos from build season, competition days, long van rides, and the
            rare moment something works on the first try.
          </p>
        </div>
      </section>

      <section className="border-b border-ink-900/10 bg-bone-50">
        <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <EmptyState
            label="0 photos on file"
            title="The darkroom is still being set up."
            description="We're compiling photos from past and current seasons. Check back during build season — we'll add bench shots, match photos, and team portraits as we shoot them."
            action={
              <a
                href="#/updates"
                className="inline-flex items-center gap-2 bg-ink-900 px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 hover:bg-spark transition-colors"
              >
                Watch updates instead
              </a>
            }
          />

          {/* Film-strip style placeholder frames */}
          <div className="mt-14">
            <div className="mb-5 flex items-end justify-between">
              <h2 className="label-stencil !text-sm !tracking-[0.2em] text-ink-900">
                // Roll 001 · Queued
              </h2>
              <span className="font-mono text-[11px] text-ink-500">
                pending ingest
              </span>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="group relative flex flex-col gap-2 border-2 border-ink-900/10 bg-bone-100/60 p-2 transition-colors hover:border-ink-900"
                >
                  <div className="relative aspect-[4/3] w-full overflow-hidden bg-bone-200">
                    <div className="grid-bg-fine absolute inset-0" aria-hidden />
                    <div className="absolute inset-0 flex items-center justify-center font-mono text-[10px] uppercase tracking-widest text-ink-500">
                      Frame {String(i + 1).padStart(2, "0")}
                    </div>
                    <svg
                      aria-hidden
                      className="absolute left-2 top-2 h-3 w-3 text-ink-400"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path d="M4 7h3l2-2h6l2 2h3v12H4z" />
                      <circle cx="12" cy="13" r="4" />
                    </svg>
                  </div>
                  <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-widest text-ink-500">
                    <span>FT-14579</span>
                    <span>{String(i + 1).padStart(2, "0")}/36</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
