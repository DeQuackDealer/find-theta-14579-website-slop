import { cn } from '../utils/cn';
import { EmptyState } from '../components/EmptyState';
import { PageHeader } from '../components/PageHeader';
import { Arrow } from '../components/Icons';

type GalleryProps = {
  onNavigate: (path: string) => void;
};

export function Gallery({ onNavigate }: GalleryProps) {
  const placeholders = Array.from({ length: 9 });

  return (
    <div>
      <PageHeader
        eyebrow="05 / Gallery"
        title={
          <>
            From the build room,
            <br />
            <em className="text-amber not-italic">to the field.</em>
          </>
        }
        subtitle="Candid photographs, match shots, and team moments. We're still rolling film this season — the archive will populate as events happen."
        meta={[
          { label: 'Photos', value: '0' },
          { label: 'Events', value: '0' },
          { label: 'Seasons', value: '1' },
          { label: 'Updated', value: 'Live' },
        ]}
      />

      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-24">
          {/* Masonry-ish grid of placeholder tiles */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {placeholders.map((_, i) => {
              const sizes = [
                'aspect-square',
                'aspect-[4/5]',
                'aspect-video',
                'aspect-[3/4]',
                'aspect-square',
                'aspect-video',
                'aspect-[4/5]',
                'aspect-square',
                'aspect-[3/4]',
              ];
              return (
                <div
                  key={i}
                  className={cn(
                    'relative group border border-line bg-ink-2 overflow-hidden',
                    sizes[i % sizes.length],
                    i === 0 && 'col-span-2 md:col-span-2 row-span-2 aspect-auto md:aspect-auto aspect-square'
                  )}
                >
                  <div className="absolute inset-0 grid-bg-fine opacity-40" />
                  <div
                    className="absolute inset-0 opacity-20"
                    style={{
                      background:
                        i % 3 === 0
                          ? 'radial-gradient(circle at 30% 30%, rgba(255,107,26,0.4), transparent 60%)'
                          : i % 3 === 1
                          ? 'radial-gradient(circle at 70% 60%, rgba(0,229,199,0.25), transparent 60%)'
                          : 'none',
                    }}
                  />
                  <div className="absolute top-3 left-3 font-mono text-[9px] uppercase tracking-[0.2em] text-ash/80">
                    IMG_{String(i + 1).padStart(3, '0')}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <svg
                      viewBox="0 0 60 40"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth={1}
                      className="w-16 md:w-20 text-line group-hover:text-line/50 transition-colors"
                    >
                      <rect x="2" y="6" width="56" height="32" />
                      <circle cx="30" cy="22" r="8" />
                      <circle cx="30" cy="22" r="3" />
                      <path d="M22 2h-6v6M38 2h6v6" />
                    </svg>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between">
                    <div className="font-mono text-[9px] uppercase tracking-[0.2em] text-ash/60">
                      Pending upload
                    </div>
                    <div className="font-mono text-[9px] text-ash/60 tabular-nums">
                      {String(i + 1).padStart(3, '0')} / 000
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-16 md:mt-20 max-w-3xl">
            <EmptyState
              tag="Gallery queue"
              title="The archive will grow with the season."
              description="We take photos at every stage — sketch reviews, late nights in the shop, qualifiers, and the occasional in-n-out on the drive home. As competitions wrap and the season progresses, this grid will fill with real imagery. Check back, or follow along in updates."
            >
              <button
                onClick={() => onNavigate('/updates')}
                className="group inline-flex items-center gap-3 bg-chalk text-ink font-mono uppercase tracking-[0.15em] text-xs px-5 py-3 hover:bg-amber transition-colors"
              >
                <span>Read updates</span>
                <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </EmptyState>
          </div>
        </div>
      </section>
    </div>
  );
}

