import { EmptyState } from '../components/EmptyState';
import { PageHeader } from '../components/PageHeader';
import { Arrow } from '../components/Icons';

type UpdatesProps = {
  onNavigate: (path: string) => void;
};

const upcoming = [
  { label: 'Season kickoff', date: 'TBD', status: 'Scheduled' },
  { label: 'Qualifier #1', date: 'TBD', status: 'Pending' },
  { label: 'Regional championship', date: 'TBD', status: 'Pending' },
];

export function Updates({ onNavigate }: UpdatesProps) {
  return (
    <div>
      <PageHeader
        eyebrow="06 / Updates"
        title={
          <>
            Field notes,
            <br />
            <span className="text-stroke">build logs, dispatches.</span>
          </>
        }
        subtitle="Long-form writeups from the build room and the competition floor. New posts land here as we progress through the season."
        meta={[
          { label: 'Posts', value: '0' },
          { label: 'This season', value: '0' },
          { label: 'Next post', value: 'Soon' },
          { label: 'Subscribers', value: '—' },
        ]}
      />

      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-24">
          {/* Post list skeleton */}
          <div className="mb-16 md:mb-20 border-t border-line">
            {[1, 2, 3].map((i) => (
              <article
                key={i}
                className="group relative grid md:grid-cols-12 gap-4 md:gap-8 py-6 md:py-8 border-b border-line cursor-not-allowed opacity-60"
              >
                <div className="md:col-span-2 font-mono text-[11px] text-ash flex items-start gap-2 pt-1">
                  <span className="inline-block w-1.5 h-1.5 mt-1 bg-line" />
                  <span>POST · 00{i}</span>
                </div>
                <div className="md:col-span-7">
                  <h3 className="font-sans text-xl md:text-3xl font-medium text-chalk/80 group-hover:text-chalk transition-colors tracking-tight leading-tight mb-2">
                    {i === 1
                      ? 'Kickoff: reading the manual and choosing our battles.'
                      : i === 2
                      ? 'Prototyping the intake: three iterations, one lesson.'
                      : 'Autonomous route planning before we even have a drive base.'}
                  </h3>
                  <p className="text-ash text-sm md:text-base leading-relaxed">
                    {i === 1
                      ? 'Breaking down the game manual, scoring what matters, and placing early bets on mechanism complexity.'
                      : i === 2
                      ? 'What we learned testing three different intake geometries against the clock and the game pieces.'
                      : 'Why we started writing autonomous before our chassis was even riveted together.'}
                  </p>
                </div>
                <div className="md:col-span-2 md:text-right font-mono text-[11px] text-ash pt-1">
                  {i === 1 ? 'Pre-season' : 'Draft'}
                </div>
                <div className="md:col-span-1 flex md:justify-end items-start pt-1">
                  <Arrow className="w-4 h-4 text-line group-hover:text-ash transition-colors" />
                </div>
              </article>
            ))}
          </div>

          <div className="grid md:grid-cols-12 gap-8 md:gap-12">
            <div className="md:col-span-7">
              <EmptyState
                tag="No posts yet"
                title="The first dispatch is in draft."
                description="We're a young team moving fast at the start of the season. Once we've got real build progress to write about (and a spare minute between iterations), you'll find it here. Expect unpolished, honest engineering notes, not press releases."
              >
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => onNavigate('/sponsors')}
                    className="group inline-flex items-center gap-3 bg-amber text-ink font-mono uppercase tracking-[0.15em] text-xs px-5 py-3 hover:bg-amber-bright transition-colors"
                  >
                    <span>Support the team</span>
                    <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </button>
                  <a
                    href="mailto:contact@findtheta.org"
                    className="group inline-flex items-center gap-3 border border-line text-chalk font-mono uppercase tracking-[0.15em] text-xs px-5 py-3 hover:border-amber hover:text-amber transition-colors"
                  >
                    <span>Say hi</span>
                    <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </a>
                </div>
              </EmptyState>
            </div>

            <div className="md:col-span-5">
              <div className="relative border border-line bg-ink-2 p-6 md:p-8">
                <span className="corner-ticks absolute inset-0 pointer-events-none" />
                <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-6 flex items-center gap-3">
                  <span className="inline-block w-6 h-px bg-amber" />
                  Schedule
                </div>
                <h3 className="font-sans text-2xl font-semibold text-chalk tracking-tight mb-6">
                  Upcoming events
                </h3>
                <ul className="space-y-0 border-t border-line">
                  {upcoming.map((e, i) => (
                    <li
                      key={i}
                      className="flex items-center justify-between py-4 border-b border-line"
                    >
                      <div>
                        <div className="text-chalk font-medium">{e.label}</div>
                        <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-ash mt-0.5">
                          {e.status}
                        </div>
                      </div>
                      <div className="font-mono text-[11px] text-ash tabular-nums">
                        {e.date}
                      </div>
                    </li>
                  ))}
                </ul>
                <p className="mt-5 text-xs text-ash font-mono leading-relaxed">
                  Confirmed event dates will appear here once published by FIRST.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
