import EmptyState from "../components/EmptyState";

export default function Updates() {
  return (
    <>
      <section className="relative overflow-hidden border-b-2 border-ink-900 bg-ink-900 text-bone-50">
        <div className="grid-bg absolute inset-0 opacity-[0.08]" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.25em]">
            <span className="text-bone-300/70">Logbook</span>
            <span className="h-3 w-px bg-bone-300/30" />
            <span className="text-spark-bright">Updates</span>
          </div>
          <h1 className="mt-6 font-display text-[clamp(2.5rem,8vw,6rem)] leading-[0.9] tracking-tight">
            Transmission <br />
            <span className="text-spark-bright">from the pits.</span>
          </h1>
          <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-bone-300/80">
            Build logs, match reports, post-mortems, and the occasional 2a.m.
            debugging post. Season updates as they happen.
          </p>
        </div>
      </section>

      <section className="border-b border-ink-900/10 bg-bone-50">
        <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <EmptyState
            label="Incoming transmission"
            title="No transmissions logged yet."
            description="We're still writing the first entry. When build season kicks into gear, you'll find weekly build logs, match recaps, and honest post-mortems here."
          />

          {/* Future timeline skeleton */}
          <div className="mt-16 relative">
            <h2 className="label-stencil !text-sm !tracking-[0.2em] text-ink-900 mb-8">
              // Timeline · Queued
            </h2>
            <ol className="relative space-y-6 border-l-2 border-dashed border-ink-900/20 pl-6">
              {[
                {
                  status: "NEXT",
                  title: "Kickoff &amp; game analysis",
                  meta: "Week 00",
                },
                {
                  status: "NEXT",
                  title: "First prototype drivetrain",
                  meta: "Week 02",
                },
                {
                  status: "NEXT",
                  title: "Mechanism review &amp; cutdown",
                  meta: "Week 04",
                },
                {
                  status: "NEXT",
                  title: "Systems integration &amp; code freeze",
                  meta: "Week 07",
                },
                {
                  status: "NEXT",
                  title: "First qualifier",
                  meta: "TBD",
                },
              ].map((e, i) => (
                <li key={i} className="relative">
                  <span className="absolute -left-[33px] top-1 flex h-5 w-5 items-center justify-center border-2 border-spark bg-bone-50">
                    <span className="h-1.5 w-1.5 bg-spark tick-dot" />
                  </span>
                  <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-ink-900/10 pb-4">
                    <div>
                      <span className="label-stencil !text-[10px] !text-spark mr-2">
                        {e.status}
                      </span>
                      <span
                        className="font-display text-lg tracking-tight text-ink-900"
                        dangerouslySetInnerHTML={{ __html: e.title }}
                      />
                    </div>
                    <span className="font-mono text-[11px] text-ink-500">
                      {e.meta}
                    </span>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>
    </>
  );
}
