import { EmptyState } from '../components/EmptyState';
import { PageHeader } from '../components/PageHeader';
import { Arrow } from '../components/Icons';

type FleetProps = {
  onNavigate: (path: string) => void;
};

export function Fleet({ onNavigate }: FleetProps) {
  return (
    <div>
      <PageHeader
        eyebrow="04 / The fleet"
        title={
          <>
            Every machine,
            <br />
            <span className="text-stroke">one season at a time.</span>
          </>
        }
        subtitle="A rolling archive of every robot we've designed, built, and fielded — from our first prototype to whatever we're putting on the field this year."
        meta={[
          { label: 'Robots logged', value: '0' },
          { label: 'Current season', value: '2025–26' },
          { label: 'Next event', value: 'TBD' },
          { label: 'Last updated', value: 'Live' },
        ]}
      />

      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-24">
          <EmptyState
            tag="Awaiting fleet data"
            title="Our first chassis is in the works."
            description="We're currently in the build phase. Once the season is underway and we've locked in our competition robot, this page will feature full breakdowns: CAD screenshots, weight budgets, subsystem specs, match performance, and everything we learned along the way."
            className="max-w-4xl"
          >
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => onNavigate('/updates')}
                className="group inline-flex items-center gap-3 bg-amber text-ink font-mono uppercase tracking-[0.15em] text-xs px-5 py-3 hover:bg-amber-bright transition-colors"
              >
                <span>Follow build updates</span>
                <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button
                onClick={() => onNavigate('/sponsors')}
                className="group inline-flex items-center gap-3 border border-line text-chalk font-mono uppercase tracking-[0.15em] text-xs px-5 py-3 hover:border-amber hover:text-amber transition-colors"
              >
                <span>Help us build it</span>
                <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </EmptyState>

          {/* Data table skeleton */}
          <div className="mt-12 md:mt-16 border border-line">
            <div className="flex items-center justify-between px-5 md:px-6 py-4 border-b border-line bg-ink-2">
              <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-ash">
                // Fleet roster
              </div>
              <div className="font-mono text-[10px] text-ash">
                SORTED BY: SEASON ↓
              </div>
            </div>
            <div className="divide-y divide-line">
              {[
                { season: '2025–26', name: 'Pending designation', status: 'In design', weight: '—', drive: '—' },
                { season: '—', name: 'Unspecified', status: 'Archived', weight: '—', drive: '—' },
              ].map((row, i) => (
                <div
                  key={i}
                  className="grid grid-cols-12 gap-4 px-5 md:px-6 py-5 items-center hover:bg-ink-2 transition-colors"
                >
                  <div className="col-span-2 md:col-span-1 font-mono text-[11px] text-ash">{row.season}</div>
                  <div className="col-span-5 md:col-span-4 font-sans text-chalk font-medium">
                    {row.name}
                  </div>
                  <div className="col-span-5 md:col-span-2 font-mono text-[11px] text-amber uppercase tracking-wider">
                    {row.status}
                  </div>
                  <div className="hidden md:block col-span-2 font-mono text-[11px] text-ash">
                    {row.weight}
                  </div>
                  <div className="hidden md:block col-span-2 font-mono text-[11px] text-ash">
                    {row.drive}
                  </div>
                  <div className="hidden md:flex col-span-1 justify-end">
                    <Arrow className="w-4 h-4 text-ash group-hover:text-amber" />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Subsystems preview */}
          <div className="mt-16 md:mt-20">
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-6 flex items-center gap-3">
              <span className="inline-block w-6 h-px bg-amber" />
              What we're building
            </div>
            <h3 className="font-sans text-2xl md:text-4xl font-semibold tracking-tight text-chalk mb-8 max-w-2xl">
              Every season we start from first principles.
            </h3>
            <div className="grid md:grid-cols-3 gap-px bg-line border border-line">
              {[
                { num: '01', title: 'Drive base', desc: 'The foundation — low, rigid, and fast. Tuned for the specific field geometry of each season.' },
                { num: '02', title: 'Manipulator', desc: 'Intake, transfer, and outtake designed around the game pieces. Iterated more than anything else.' },
                { num: '03', title: 'Autonomous', desc: 'Sensor fusion, odometry, and path planning that turns the first 30 seconds of every match into an advantage.' },
              ].map((s) => (
                <div key={s.num} className="bg-ink p-6 md:p-8">
                  <div className="font-mono text-[10px] text-ash mb-4">{s.num}</div>
                  <div className="font-sans text-chalk font-medium text-xl mb-2">{s.title}</div>
                  <div className="text-ash text-sm leading-relaxed">{s.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
