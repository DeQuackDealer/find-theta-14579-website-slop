import EmptyState from "../components/EmptyState";
import ThetaGlyph from "../components/ThetaGlyph";

export default function Fleet() {
  return (
    <>
      <PageHeader />
      <section className="border-b border-ink-900/10 bg-bone-50">
        <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <EmptyState
            label="Fleet manifest"
            title="Hangar is being wired."
            description="The robot registry is under construction. When the current season's machine leaves the bench, we'll publish its full spec sheet — dimensions, weight, drivebase, mechanisms, code, and a post-mortem. Check back after kickoff."
            icon={
              <span className="grid h-8 w-8 place-items-center border border-ink-900/20 bg-bone-50 text-spark">
                <ThetaGlyph size={18} className="text-spark" accent />
              </span>
            }
          />

          {/* Future robot cards — placeholder grid */}
          <div className="mt-16">
            <div className="mb-6 flex items-end justify-between">
              <h3 className="label-stencil !text-sm !tracking-[0.2em] text-ink-900">
                // Season archive
              </h3>
              <span className="font-mono text-[11px] text-ink-500">
                sorted by season · newest first
              </span>
            </div>

            <div className="grid gap-px bg-ink-900/10 sm:grid-cols-2 lg:grid-cols-3">
              {["Current season", "Last season", "Archive 01"].map((label, i) => (
                <div
                  key={label}
                  className="relative flex flex-col gap-4 bg-bone-50 p-6 transition-colors hover:bg-bone-100/80"
                >
                  <div className="flex items-start justify-between">
                    <span className="font-mono text-[11px] font-semibold uppercase tracking-widest text-spark">
                      Slot {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="font-mono text-[11px] text-ink-400">
                      {i === 0 ? "WIP" : "LOCKED"}
                    </span>
                  </div>
                  {/* Technical drawing placeholder */}
                  <div className="relative aspect-[4/3] w-full overflow-hidden border border-ink-900/10 bg-bone-100">
                    <div className="grid-bg-fine absolute inset-0" aria-hidden />
                    <svg
                      viewBox="0 0 200 150"
                      className="absolute inset-0 h-full w-full text-ink-900/30"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="0.75"
                    >
                      <rect x="40" y="60" width="120" height="50" />
                      <circle cx="55" cy="115" r="12" />
                      <circle cx="145" cy="115" r="12" />
                      <path d="M40 60 L100 30 L160 60" />
                      <path d="M100 30 v-10" />
                      <text x="10" y="20" fontSize="6" fontFamily="monospace" fill="currentColor">
                        {i === 0 ? "[BUILDING...]" : "[PENDING]"}
                      </text>
                      {i === 0 && (
                        <g stroke="var(--color-spark)" strokeWidth="1">
                          <path d="M100 30 L160 15" />
                          <text x="162" y="15" fontSize="6" fill="var(--color-spark)" fontFamily="monospace">θ</text>
                        </g>
                      )}
                    </svg>
                    {i === 0 && (
                      <span className="absolute right-2 top-2 flex items-center gap-1.5 bg-spark px-1.5 py-0.5 font-mono text-[9px] font-semibold uppercase tracking-widest text-bone-50">
                        <span className="h-1 w-1 rounded-full bg-bone-50 tick-dot" />
                        Building
                      </span>
                    )}
                  </div>
                  <div>
                    <div className="font-display text-xl leading-none tracking-tight text-ink-900">
                      {label}
                    </div>
                    <div className="mt-2 font-mono text-[11px] text-ink-500">
                      {i === 0
                        ? "CAD locked · Machining in progress"
                        : "Spec sheet pending teardown"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function PageHeader() {
  return (
    <section className="relative overflow-hidden border-b-2 border-ink-900 bg-ink-900 text-bone-50">
      <div className="grid-bg absolute inset-0 opacity-[0.08]" aria-hidden />
      <div className="relative mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
        <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.25em]">
          <span className="text-bone-300/70">Appendix</span>
          <span className="h-3 w-px bg-bone-300/30" />
          <span className="text-spark-bright">Fleet</span>
        </div>
        <h1 className="mt-6 font-display text-[clamp(2.5rem,8vw,6rem)] leading-[0.9] tracking-tight">
          The machines <br />
          <span className="text-spark-bright">we build.</span>
        </h1>
        <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-bone-300/80">
          Every robot Find Theta has ever built, season by season — what worked,
          what didn't, and what we broke in between.
        </p>
      </div>
    </section>
  );
}
