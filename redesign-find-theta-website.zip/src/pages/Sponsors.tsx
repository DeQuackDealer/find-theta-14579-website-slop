import EmptyState from "../components/EmptyState";

const tiers = [
  {
    name: "Title",
    amount: "$5,000+",
    perks: [
      "Logo on robot bumpers & team uniforms",
      "Featured in all match-day media",
      "Dedicated spotlight on our homepage",
      "Team demo at your location",
    ],
    color: "bg-ink-900 text-bone-50",
  },
  {
    name: "Premier",
    amount: "$2,500+",
    perks: [
      "Logo on robot and pit banner",
      "Named mention at events and in updates",
      "Season-long social media callouts",
    ],
    color: "bg-bone-100 text-ink-900",
  },
  {
    name: "Partner",
    amount: "$1,000+",
    perks: [
      "Logo on our website sponsors page",
      "Mention in end-of-season report",
      "Swag pack & team thank-you card",
    ],
    color: "bg-bone-50 text-ink-900",
  },
  {
    name: "Friend",
    amount: "Any amount",
    perks: [
      "Listed as a supporter",
      "Our eternal gratitude",
      "Tax-deductible receipt",
    ],
    color: "bg-bone-50 text-ink-900",
  },
];

export default function Sponsors() {
  return (
    <>
      <section className="relative overflow-hidden border-b-2 border-ink-900 bg-ink-900 text-bone-50">
        <div className="grid-bg absolute inset-0 opacity-[0.08]" aria-hidden />
        <div className="relative mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.25em]">
            <span className="text-bone-300/70">Back the team</span>
            <span className="h-3 w-px bg-bone-300/30" />
            <span className="text-spark-bright">Sponsors</span>
          </div>
          <h1 className="mt-6 font-display text-[clamp(2.5rem,8vw,6rem)] leading-[0.9] tracking-tight">
            Robotics is not cheap.
            <br />
            <span className="text-spark-bright">Neither is winning.</span>
          </h1>
          <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-bone-300/80">
            Every dollar goes to aluminium, motors, electronics, event fees,
            and the long, expensive road to a championship. Meet the
            organisations and individuals who make Find Theta possible —
            or join them.
          </p>
        </div>
      </section>

      {/* Current sponsors (empty state, no sponsors claimed yet) */}
      <section className="border-b border-ink-900/10 bg-bone-50">
        <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <EmptyState
            label="0 sponsors on file"
            title="Founding sponsor slots are open."
            description="We're assembling our founding sponsor roster right now. If you or your organisation would like to be the first name on this page, we'd love to hear from you."
            action={
              <a
                href="mailto:contact@findtheta.org?subject=Sponsorship"
                className="inline-flex items-center gap-2 bg-ink-900 px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 hover:bg-spark transition-colors"
              >
                Get in touch
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
                  <path d="M1 6h10M7 2l4 4-4 4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
                </svg>
              </a>
            }
          />
        </div>
      </section>

      {/* Sponsorship tiers */}
      <section className="border-b border-ink-900/10 bg-bone-100/60">
        <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 sm:py-20 lg:px-12 lg:py-24">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <h2 className="font-display text-3xl leading-tight tracking-tight sm:text-5xl">
              Sponsorship <span className="text-spark">tiers</span>.
            </h2>
            <p className="max-w-sm font-mono text-[12px] leading-relaxed text-ink-500">
              {"//"} All levels are flexible. Cash, parts, mentorship, and
              in-kind donations all help. We'll work with you.
            </p>
          </div>

          <div className="mt-12 grid gap-px bg-ink-900/10 sm:grid-cols-2 lg:grid-cols-4">
            {tiers.map((t) => (
              <div
                key={t.name}
                className={`flex flex-col gap-5 p-6 sm:p-7 ${t.color}`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-2xl leading-none tracking-tight">
                    {t.name}
                  </span>
                  <span className="font-mono text-[11px] uppercase tracking-widest opacity-70">
                    {t.amount}
                  </span>
                </div>
                <ul className="flex-1 space-y-2.5 text-[13px] leading-relaxed">
                  {t.perks.map((p) => (
                    <li key={p} className="flex gap-2">
                      <span
                        aria-hidden
                        className="mt-[7px] h-[5px] w-[5px] shrink-0 bg-spark"
                      />
                      <span
                        className={
                          t.color.includes("bg-ink-900")
                            ? "text-bone-100/90"
                            : "text-ink-700"
                        }
                      >
                        {p}
                      </span>
                    </li>
                  ))}
                </ul>
                <a
                  href="mailto:contact@findtheta.org?subject=Sponsorship"
                  className={`inline-flex items-center justify-center gap-2 border px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider transition-colors ${
                    t.color.includes("bg-ink-900")
                      ? "border-bone-50/30 text-bone-50 hover:bg-spark-bright hover:border-spark-bright hover:text-ink-900"
                      : "border-ink-900/20 text-ink-900 hover:bg-ink-900 hover:text-bone-50"
                  }`}
                >
                  Select {t.name}
                </a>
              </div>
            ))}
          </div>

          <div className="mt-10 flex flex-col gap-4 rounded-none border-l-4 border-spark bg-bone-50 p-6 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm leading-relaxed text-ink-700">
              Something else in mind — mentorship, parts donations, a workshop
              tour? Sponsorship isn't one-size-fits-all. Email us and we'll
              figure out a partnership that works.
            </p>
            <a
              href="mailto:contact@findtheta.org"
              className="shrink-0 font-mono text-xs font-semibold uppercase tracking-wider text-ink-900 hover:text-spark"
            >
              contact@findtheta.org →
            </a>
          </div>
        </div>
      </section>
    </>
  );
}
