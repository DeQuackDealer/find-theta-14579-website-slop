import { PageHeader } from '../components/PageHeader';
import { Arrow, ExternalArrow, Wrench, Chip, Cog, Bolt } from '../components/Icons';

const tiers = [
  {
    name: 'Title',
    amount: '$3,000+',
    perks: ['Large logo on robot', 'Logo on team apparel', 'Featured on website & social', 'Dedicated shoutout at events'],
    color: 'amber',
  },
  {
    name: 'Platinum',
    amount: '$1,500+',
    perks: ['Logo on robot', 'Logo on apparel', 'Website recognition', 'Social media features'],
    color: 'chalk',
  },
  {
    name: 'Alliance',
    amount: '$500+',
    perks: ['Logo on apparel', 'Website recognition', 'Team thank-you pack'],
    color: 'ash',
  },
  {
    name: 'Friend',
    amount: 'Any',
    perks: ['Website recognition', 'Our sincere thanks'],
    color: 'steel',
  },
];

const funds = [
  { icon: Wrench, label: 'Parts & materials', detail: 'Aluminum extrusion, fasteners, polycarbonate, 3D printer filament.' },
  { icon: Chip, label: 'Electronics & sensors', detail: 'REV hubs, motors, servos, cameras, and control system components.' },
  { icon: Cog, label: 'Tools & equipment', detail: 'Shop tools, a 3D printer, test rigs, and maintenance supplies.' },
  { icon: Bolt, label: 'Competition travel', detail: 'Registration fees, transport, accommodation, and field access.' },
];

export function Sponsors() {
  return (
    <div>
      <PageHeader
        eyebrow="07 / Sponsors"
        title={
          <>
            A community team,
            <br />
            <em className="text-amber not-italic">backed by people who believe in it.</em>
          </>
        }
        subtitle="Robotics isn't cheap. Every part, tool, and trip to competition is funded through sponsorship. If you or your organisation want in, we'd love to talk."
        meta={[
          { label: 'Sponsors', value: '0' },
          { label: 'Funded', value: '0%' },
          { label: 'Season', value: '2025–26' },
          { label: 'Status', value: 'Recruiting' },
        ]}
      />

      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-24">
          {/* Sponsor wall empty state */}
          <div className="relative border border-line bg-ink-2 p-8 md:p-14 mb-16 md:mb-20 overflow-hidden">
            <span className="corner-ticks absolute inset-0 pointer-events-none" />
            <div className="absolute inset-0 grid-bg-fine opacity-40 pointer-events-none" />
            <div className="relative grid md:grid-cols-12 gap-8 items-center">
              <div className="md:col-span-8">
                <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-4 flex items-center gap-3">
                  <span className="w-2 h-2 bg-amber animate-[pulseDot_2s_ease-in-out_infinite]" />
                  Sponsor roster · open
                </div>
                <h2 className="font-sans text-3xl md:text-5xl font-semibold tracking-tight text-chalk leading-[1.05] max-w-2xl">
                  Want to be the first name on this wall?
                </h2>
                <p className="mt-5 text-ash text-base md:text-lg leading-relaxed max-w-2xl">
                  We're building our sponsor roster for this season. Whether you're a local
                  business, a family friend, or an organisation that believes in student engineering,
                  there's a place for you here.
                </p>
                <div className="mt-7 flex flex-wrap gap-3">
                  <a
                    href="mailto:contact@findtheta.org?subject=Sponsorship"
                    className="group inline-flex items-center gap-3 bg-amber text-ink font-mono uppercase tracking-[0.15em] text-xs px-5 py-3.5 hover:bg-amber-bright transition-colors"
                  >
                    <span>Get in touch</span>
                    <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </a>
                  <a
                    href="#"
                    className="group inline-flex items-center gap-3 border border-line text-chalk font-mono uppercase tracking-[0.15em] text-xs px-5 py-3.5 hover:border-amber hover:text-amber transition-colors"
                  >
                    <span>Sponsorship prospectus</span>
                    <ExternalArrow className="w-4 h-4" />
                  </a>
                </div>
              </div>
              <div className="md:col-span-4">
                <div className="aspect-square border border-line bg-ink flex flex-col items-center justify-center relative">
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.06] font-sans font-black text-[10rem] text-amber">
                    θ
                  </div>
                  <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-ash text-center px-4">
                    Reserved for
                    <br />
                    sponsor logo
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* What your money buys */}
          <div className="mb-16 md:mb-20">
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-6 flex items-center gap-3">
              <span className="inline-block w-6 h-px bg-amber" />
              Where the money goes
            </div>
            <h3 className="font-sans text-2xl md:text-4xl font-semibold tracking-tight text-chalk mb-10 max-w-2xl">
              100% of sponsorship goes directly to the robot and the team.
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-px bg-line border border-line">
              {funds.map((f, i) => {
                const Icon = f.icon;
                return (
                  <div key={i} className="bg-ink p-6 md:p-7 hover:bg-ink-2 transition-colors">
                    <Icon className="w-7 h-7 text-amber mb-4" />
                    <div className="font-sans text-chalk font-medium text-lg mb-2">{f.label}</div>
                    <div className="text-ash text-sm leading-relaxed">{f.detail}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Tiers */}
          <div>
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-6 flex items-center gap-3">
              <span className="inline-block w-6 h-px bg-amber" />
              Sponsorship tiers
            </div>
            <h3 className="font-sans text-2xl md:text-4xl font-semibold tracking-tight text-chalk mb-10 max-w-2xl">
              Pick the level that fits, or reach out to build a custom package.
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
              {tiers.map((t, i) => (
                <div
                  key={i}
                  className={
                    'relative border p-6 md:p-7 flex flex-col ' +
                    (i === 0
                      ? 'border-amber bg-amber/5'
                      : 'border-line bg-ink-2')
                  }
                >
                  {i === 0 && (
                    <div className="absolute -top-3 left-5 bg-amber text-ink font-mono text-[10px] uppercase tracking-[0.2em] px-2 py-0.5">
                      Top tier
                    </div>
                  )}
                  <span className="corner-ticks absolute inset-0 pointer-events-none" />
                  <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-ash mb-2">
                    0{i + 1}
                  </div>
                  <div className="font-sans text-2xl font-semibold text-chalk mb-1">
                    {t.name}
                  </div>
                  <div className={
                    'font-mono text-sm mb-6 ' +
                    (i === 0 ? 'text-amber' : 'text-chalk')
                  }>
                    {t.amount}
                  </div>
                  <ul className="space-y-2 text-sm text-ash leading-relaxed mb-6 flex-1">
                    {t.perks.map((p, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <span className="text-amber mt-1.5 w-1 h-1 shrink-0 bg-amber" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href={`mailto:contact@findtheta.org?subject=${t.name} sponsorship`}
                    className={
                      'group inline-flex items-center justify-between gap-2 font-mono uppercase tracking-[0.15em] text-xs px-4 py-2.5 transition-colors ' +
                      (i === 0
                        ? 'bg-amber text-ink hover:bg-amber-bright'
                        : 'border border-line text-chalk hover:border-amber hover:text-amber')
                    }
                  >
                    <span>Select</span>
                    <Arrow className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* In-kind */}
          <div className="mt-16 md:mt-20 border border-line bg-ink-2 p-8 md:p-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="max-w-2xl">
              <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-3">
                Not cash? No problem.
              </div>
              <h3 className="font-sans text-2xl md:text-3xl font-semibold text-chalk tracking-tight">
                We also welcome in-kind donations: parts, 3D printing filament,
                tools, mentorship time, or machine shop access.
              </h3>
            </div>
            <a
              href="mailto:contact@findtheta.org?subject=In-kind donation"
              className="group shrink-0 inline-flex items-center gap-3 border border-chalk text-chalk font-mono uppercase tracking-[0.15em] text-xs px-5 py-3.5 hover:bg-chalk hover:text-ink transition-colors"
            >
              <span>Offer in-kind</span>
              <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
