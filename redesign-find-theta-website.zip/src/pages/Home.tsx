import { cn } from "../utils/cn";
import BuildClock from "../components/BuildClock";
import SectionHeader from "../components/SectionHeader";
import ThetaGlyph from "../components/ThetaGlyph";
import EmptyState from "../components/EmptyState";

const verbs = [
  "Build",
  "Test",
  "Break",
  "Iterate",
  "Compete",
  "Learn faster",
  "Ship",
  "Find Theta",
];

const pillars = [
  {
    num: "01",
    title: "Design",
    blurb:
      "Iterating mechanisms in CAD — from napkin sketch to competition-ready, every subassembly is measured, torqued, and weighed before a single bolt is turned.",
    icon: (
      <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square">
        <circle cx="16" cy="16" r="11" />
        <circle cx="16" cy="16" r="3" />
        <path d="M16 2v5M16 25v5M2 16h5M25 16h5M5 5l3.5 3.5M23.5 23.5L27 27M27 5l-3.5 3.5M8.5 23.5L5 27" />
      </svg>
    ),
  },
  {
    num: "02",
    title: "Fabrication",
    blurb:
      "Machining, 3D printing, and assembling every part in-house. If it goes on the robot, one of us made it — and can remake it faster.",
    icon: (
      <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square">
        <path d="M26 6l-4-4-8 8v4l-8 8 4 4 8-8h4l8-8-4-4z" />
        <path d="M14 18l4-4" />
      </svg>
    ),
  },
  {
    num: "03",
    title: "Programming",
    blurb:
      "Autonomous routines, teleop controls, and sensor fusion. Roadrunner, OpenCV, PID — the code that turns a bucket of bolts into a predator on the field.",
    icon: (
      <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square">
        <rect x="4" y="6" width="24" height="20" rx="1" />
        <path d="M10 12h4M18 12h4M10 17h12M10 22h8" />
      </svg>
    ),
  },
  {
    num: "04",
    title: "Strategy",
    blurb:
      "Reading the field, scouting opponents, adapting match to match. The best robot in the world still loses if it doesn't pick the right fight.",
    icon: (
      <svg viewBox="0 0 32 32" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="square">
        <path d="M4 28L28 4M28 4H10M28 4v18" />
      </svg>
    ),
  },
];

const stats = [
  { value: "0+", label: "Awards & honours", note: "First entry pending." },
  { value: "0+", label: "Members & alumni", note: "Across all seasons." },
  { value: "0", label: "World championships", note: "Qualification in progress." },
  { value: "0%", label: "Qualification rate", note: "Working toward it." },
];

export default function Home() {
  return (
    <>
      <Hero />
      <Philosophy />
      <Pillars />
      <ProcessMarquee />
      <ByTheNumbers />
      <OnTheField />
      <RecordBook />
      <SponsorBand />
      <ContactCTA />
    </>
  );
}

/* ----------------------------- HERO ----------------------------- */

function Hero() {
  return (
    <section className="relative overflow-hidden border-b-2 border-ink-900">
      <div className="grid-bg absolute inset-0" aria-hidden />
      {/* Subtle angle marks */}
      <svg
        aria-hidden
        className="pointer-events-none absolute right-0 top-0 h-full w-1/2 max-w-xl opacity-[0.08]"
        viewBox="0 0 400 800"
        preserveAspectRatio="xMaxYMid slice"
      >
        <g stroke="currentColor" strokeWidth="1" fill="none" className="text-ink-900">
          <path d="M0 0 L400 0 L0 800 Z" />
          <path d="M400 0 L400 800" strokeDasharray="4 6" />
          <path d="M0 0 L200 800" />
          <path d="M0 200 L400 200" />
          <path d="M0 400 L400 400" />
          <path d="M0 600 L400 600" />
        </g>
      </svg>

      <div className="relative mx-auto max-w-[1400px] px-5 pt-8 pb-16 sm:px-8 sm:pt-10 lg:px-12 lg:pt-12 lg:pb-24">
        {/* Top bar: status + team number */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <BuildClock />
          <div className="flex items-center gap-3 font-mono text-[11px] font-semibold uppercase tracking-[0.25em] text-ink-600">
            <span>First Tech Challenge</span>
            <span className="h-3 w-px bg-ink-900/20" />
            <span className="text-spark">Team 14579</span>
          </div>
        </div>

        {/* Hero grid */}
        <div className="mt-12 grid gap-10 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-8">
            <div className="label-stencil text-ink-500 mb-6 flex items-center gap-3">
              <span className="h-px w-8 bg-ink-900/40" />
              <span id="home-top">Student-led // Season active // Team 14579</span>
            </div>
            <h1 className="font-display text-[clamp(3.2rem,11vw,9.5rem)] leading-[0.86] tracking-[-0.02em] text-ink-900">
              FIND
              <br />
              <span className="relative inline-block">
                TH
                <span className="text-spark">Θ</span>
                TA
                {/* Theta tick marks */}
                <span
                  aria-hidden
                  className="absolute -right-3 top-1/2 hidden h-[2px] w-14 -translate-y-1/2 bg-spark md:block"
                >
                  <span className="absolute -right-0 top-1/2 h-3 w-[2px] -translate-y-1/2 bg-spark" />
                  <span className="absolute -right-0 top-1/2 h-1.5 w-1.5 -translate-y-1/2 translate-x-[1px] rounded-full bg-spark" />
                </span>
              </span>
              <span className="caret ml-1 inline-block h-[0.8em] w-[0.12em] translate-y-[0.05em] bg-spark align-middle" />
            </h1>
            <p className="mt-8 max-w-2xl text-lg leading-relaxed text-ink-700 sm:text-xl">
              A student-run FIRST Tech Challenge team building competition
              robots with the <em className="not-italic font-semibold text-ink-900">precision of the ibis</em>.
              Sharp-eyed, adaptable, and allergic to habitats that box us in.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-3">
              <a
                href="#philosophy"
                className="group inline-flex items-center gap-3 bg-ink-900 px-5 py-3 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 hover:bg-spark transition-colors"
              >
                Read the philosophy
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden className="transition-transform group-hover:translate-y-0.5">
                  <path d="M7 2v10M3 7l4 4 4-4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
                </svg>
              </a>
              <a
                href="#/fleet"
                className="inline-flex items-center gap-3 border border-ink-900/20 bg-bone-50 px-5 py-3 font-mono text-xs font-semibold uppercase tracking-wider text-ink-900 hover:border-ink-900 transition-colors"
              >
                See the fleet
              </a>
              <span className="ml-1 hidden font-mono text-[10px] uppercase tracking-widest text-ink-500 sm:inline">
                Scroll ↓ or press Tab
              </span>
            </div>
          </div>

          {/* Side panel: live telemetry card */}
          <aside className="lg:col-span-4">
            <div className="relative border-2 border-ink-900 bg-bone-100/60 p-5">
              <div className="flex items-center justify-between">
                <span className="label-stencil text-ink-500">// Telemetry</span>
                <span className="flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-widest text-spark">
                  <span className="h-1.5 w-1.5 rounded-full bg-spark tick-dot" />
                  LIVE
                </span>
              </div>
              <div className="mt-5 space-y-3 font-mono text-[12px] leading-relaxed">
                <TelemetryRow k="team_id" v="14579" />
                <TelemetryRow k="org" v="FIRST Tech Challenge" />
                <TelemetryRow k="season" v="IN_PROGRESS" highlight />
                <TelemetryRow k="mot_enc_l" v="0.00 rad" />
                <TelemetryRow k="mot_enc_r" v="0.00 rad" />
                <TelemetryRow k="theta" v="awaiting input" monospaced />
                <TelemetryRow k="state" v="DESIGN → BUILD" highlight />
              </div>
              <div className="mt-6 flex items-center justify-between border-t border-ink-900/10 pt-4">
                <span className="label-stencil text-ink-500">Mascot</span>
                <span className="font-mono text-xs font-semibold text-ink-900">
                  Ibis · <span className="text-spark">Threskiornis</span>
                </span>
              </div>
              <div className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center bg-spark font-mono text-[10px] font-bold text-bone-50">
                ▶
              </div>
            </div>

            <div className="mt-4 font-mono text-[11px] leading-relaxed text-ink-500">
              <span className="text-spark">&gt;</span> Every season we start from a bare chassis. Every season we leave with a better team.
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function TelemetryRow({
  k,
  v,
  highlight,
  monospaced,
}: {
  k: string;
  v: string;
  highlight?: boolean;
  monospaced?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <span className="shrink-0 text-ink-500">{k}:</span>
      <span
        className={cn(
          "truncate text-right",
          monospaced ? "tabular-nums" : "",
          highlight ? "font-semibold text-spark" : "text-ink-900"
        )}
      >
        {v}
      </span>
    </div>
  );
}

/* ----------------------------- PHILOSOPHY ----------------------------- */

function Philosophy() {
  return (
    <section id="philosophy" className="relative border-b border-ink-900/10 bg-bone-50">
      <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-24 lg:px-12 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeader
              number="01 /"
              kicker="Philosophy"
              title={<>Different faces every season, <span className="text-spark">the same core</span>.</>}
            />
          </div>
          <div className="lg:col-span-7 lg:pl-12 lg:border-l border-ink-900/10">
            <div className="space-y-6 text-[17px] leading-relaxed text-ink-800">
              <p>
                Find Theta is a student-led FIRST Tech Challenge team competing
                as team <span className="font-mono font-semibold text-ink-900">14579</span>.
                We design, build, and program every robot from bare chassis to
                competition-ready machine, season after season.
              </p>
              <p>
                We watch the ibis for a reason: an animal that thrives by staying
                sharp-eyed and adaptable, never boxed in by one habitat. That
                is the standard we hold our engineering to. Not the prettiest
                robot, not the most complicated robot — the one that solves the
                problem the day of the match, when the problem is different from
                the one we practiced for.
              </p>
            </div>

            {/* Two-up figure: bench + field */}
            <div className="mt-12 grid gap-4 sm:grid-cols-5">
              <figure className="sm:col-span-3 relative overflow-hidden border-2 border-ink-900">
                <div className="aspect-[4/3] w-full bg-bone-200">
                  <img
                    src="https://picsum.photos/seed/find-theta-build-bench/1200/900"
                    alt="Team members building a robot on the workbench"
                    loading="lazy"
                    className="h-full w-full object-cover grayscale contrast-110"
                  />
                </div>
                <figcaption className="flex items-center justify-between border-t-2 border-ink-900 bg-bone-50 px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-ink-700">
                  <span>Fig 01 · The bench</span>
                  <span className="text-spark">IN-HOUSE</span>
                </figcaption>
              </figure>
              <figure className="sm:col-span-2 relative overflow-hidden border-2 border-ink-900">
                <div className="aspect-[3/4] w-full bg-bone-200">
                  <img
                    src="https://picsum.photos/seed/find-theta-field-side/800/1000"
                    alt="A Find Theta robot on the competition field"
                    loading="lazy"
                    className="h-full w-full object-cover grayscale contrast-110"
                  />
                </div>
                <figcaption className="flex items-center justify-between border-t-2 border-ink-900 bg-bone-50 px-3 py-2 font-mono text-[10px] uppercase tracking-widest text-ink-700">
                  <span>Fig 02 · The field</span>
                  <span className="text-spark">DEPLOYED</span>
                </figcaption>
              </figure>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- PILLARS ----------------------------- */

function Pillars() {
  return (
    <section className="relative border-b border-ink-900/10 bg-bone-100/60">
      <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-24 lg:px-12 lg:py-28">
        <SectionHeader
          number="02 /"
          kicker="What we do"
          title={<>Four disciplines, <span className="text-spark">one machine</span>.</>}
          subtitle="Every member of Find Theta ends up fluent across disciplines, but we organize the work into four non-negotiable capability areas."
          className="mb-14"
        />
        <div className="grid gap-px bg-ink-900/10 sm:grid-cols-2 lg:grid-cols-4">
          {pillars.map((p) => (
            <article
              key={p.num}
              className="group relative flex flex-col gap-5 bg-bone-50 p-6 transition-colors hover:bg-ink-900 hover:text-bone-50 sm:p-7"
            >
              <div className="flex items-start justify-between">
                <span className="h-10 w-10 text-ink-900 transition-colors group-hover:text-spark-bright">
                  {p.icon}
                </span>
                <span className="font-mono text-[11px] font-semibold text-spark">
                  {p.num}
                </span>
              </div>
              <h3 className="font-display text-2xl leading-none tracking-tight">
                {p.title}
              </h3>
              <p className="text-[14px] leading-relaxed text-ink-600 transition-colors group-hover:text-bone-100/80">
                {p.blurb}
              </p>
              <div className="mt-auto flex items-center gap-2 font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-400 transition-colors group-hover:text-spark-bright">
                <span className="h-px w-6 bg-current" />
                Learn more
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- MARQUEE ----------------------------- */

function ProcessMarquee() {
  const loop = [...verbs, ...verbs];
  return (
    <section
      aria-label="Our process"
      className="relative overflow-hidden border-y-2 border-ink-900 bg-ink-900 py-6 text-bone-50"
    >
      <div className="flex whitespace-nowrap marquee-track">
        {loop.map((v, i) => (
          <span key={i} className="flex items-center gap-8 pr-8 font-display text-3xl tracking-tight sm:text-5xl">
            <span className={cn(v === "Find Theta" && "text-spark-bright")}>
              {v}
            </span>
            <span className="text-spark/60">
              <ThetaGlyph size={22} className="text-spark-bright" />
            </span>
          </span>
        ))}
      </div>
    </section>
  );
}

/* ----------------------------- BY THE NUMBERS ----------------------------- */

function ByTheNumbers() {
  return (
    <section className="relative border-b border-ink-900/10 bg-bone-50">
      <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-24 lg:px-12 lg:py-28">
        <div className="flex flex-col gap-10 lg:flex-row lg:items-end lg:justify-between">
          <SectionHeader
            number="03 /"
            kicker="By the numbers"
            title={<>Still writing <span className="text-spark">the record book</span>.</>}
          />
          <p className="max-w-sm font-mono text-[12px] leading-relaxed text-ink-500">
            {"//"} We're not here to pad stats. Every number below is earned in
            qualification matches and knockout brackets, not on paper.
          </p>
        </div>

        <div className="mt-14 grid gap-px bg-ink-900/10 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s) => (
            <div
              key={s.label}
              className="group relative bg-bone-50 p-6 sm:p-8 hover:bg-bone-100 transition-colors"
            >
              <div className="flex items-baseline gap-1 font-display text-6xl leading-none tracking-tight text-ink-900 sm:text-7xl">
                {s.value === "0+" ? (
                  <>
                    <span className="text-bone-300">0</span>
                    <span className="text-2xl text-spark">+</span>
                  </>
                ) : s.value === "0%" ? (
                  <>
                    <span className="text-bone-300">0</span>
                    <span className="text-2xl text-ink-400">%</span>
                  </>
                ) : (
                  <span className="text-bone-300">{s.value}</span>
                )}
              </div>
              <div className="mt-6 border-t border-ink-900/10 pt-4">
                <div className="label-stencil text-ink-800">{s.label}</div>
                <div className="mt-1 font-mono text-[11px] text-ink-500">
                  {s.note}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- ON THE FIELD ----------------------------- */

function OnTheField() {
  return (
    <section className="relative overflow-hidden border-b-2 border-ink-900 bg-ink-900 text-bone-50">
      <div className="relative">
        <div className="aspect-[21/9] w-full overflow-hidden">
          <img
            src="https://picsum.photos/seed/find-theta-competition-floor/2400/1000"
            alt="Find Theta drive team at the competition field"
            loading="lazy"
            className="h-full w-full object-cover opacity-60 grayscale"
          />
        </div>
        {/* Overlay gradient */}
        <div
          aria-hidden
          className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/40 to-transparent"
        />
        {/* Technical reticle */}
        <svg
          aria-hidden
          className="pointer-events-none absolute left-6 top-6 h-14 w-14 text-spark-bright sm:left-10 sm:top-10"
          viewBox="0 0 64 64"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
        >
          <circle cx="32" cy="32" r="28" />
          <path d="M32 2v8M32 54v8M2 32h8M54 32h8" />
          <path d="M32 32 L54 14" stroke="var(--color-spark-bright)" strokeWidth="2" />
          <circle cx="32" cy="32" r="2" fill="currentColor" />
        </svg>

        <div className="absolute inset-x-0 bottom-0">
          <div className="mx-auto flex max-w-[1400px] flex-col gap-4 px-5 py-8 sm:px-8 sm:py-12 sm:flex-row sm:items-end sm:justify-between lg:px-12">
            <div>
              <div className="label-stencil !text-spark-bright mb-3 flex items-center gap-2">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" aria-hidden>
                  <path d="M6 0l1.8 4.2L12 5l-3 3 .7 4L6 9.9 2.3 12 3 8 0 5l4.2-.8L6 0z" />
                </svg>
                On the field
              </div>
              <h2 className="font-display text-[clamp(2rem,6vw,4.5rem)] leading-[0.95] tracking-tight">
                Every match is a chance <br />
                to <span className="text-spark-bright italic font-normal">learn faster.</span>
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-3 sm:justify-end">
              <a
                href="#/gallery"
                className="inline-flex items-center gap-2 border border-bone-50/30 bg-bone-50/5 px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 backdrop-blur hover:bg-spark hover:border-spark transition-colors"
              >
                View gallery
              </a>
              <a
                href="#/updates"
                className="inline-flex items-center gap-2 bg-bone-50 px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider text-ink-900 hover:bg-spark-bright transition-colors"
              >
                Match reports
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- RECORD BOOK ----------------------------- */

function RecordBook() {
  return (
    <section className="relative border-b border-ink-900/10 bg-bone-100/50">
      <div className="mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-24 lg:px-12 lg:py-28">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <SectionHeader
              number="04 /"
              kicker="Record book"
              title={<>Awards earned <span className="text-spark">so far</span>.</>}
            />
            <div className="mt-8 font-display text-7xl leading-none tracking-tight text-ink-900 sm:text-8xl">
              <span className="text-bone-300">0</span>
              <span className="ml-2 align-top text-2xl text-spark">+</span>
            </div>
            <p className="mt-6 max-w-md text-[15px] leading-relaxed text-ink-600">
              We came here to win, but we showed up ready to lose and learn
              from it. Our first entry is still being machined on the workbench.
            </p>
          </div>

          <div className="lg:col-span-7 lg:pl-12 lg:border-l border-ink-900/10">
            <EmptyState
              label="Awaiting first result"
              title="Our first hardware is on the way."
              description="The record book starts here. Check back after the next competition — we intend to fill this page quickly."
              action={
                <a
                  href="#/updates"
                  className="inline-flex items-center gap-2 bg-ink-900 px-4 py-2.5 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 hover:bg-spark transition-colors"
                >
                  Follow the season
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden>
                    <path d="M1 6h10M7 2l4 4-4 4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
                  </svg>
                </a>
              }
            />

            {/* Table skeleton */}
            <div className="mt-6 border border-ink-900/10 bg-bone-50">
              <div className="grid grid-cols-12 border-b border-ink-900/10 bg-bone-100/70 px-4 py-2.5 font-mono text-[10px] font-semibold uppercase tracking-widest text-ink-500">
                <div className="col-span-2">Season</div>
                <div className="col-span-5">Event</div>
                <div className="col-span-5">Award</div>
              </div>
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="grid grid-cols-12 items-center border-b border-ink-900/5 px-4 py-4 last:border-b-0"
                >
                  <div className="col-span-2">
                    <div className="h-3 w-10 bg-bone-200" />
                  </div>
                  <div className="col-span-5">
                    <div className="h-3 w-32 bg-bone-200" />
                  </div>
                  <div className="col-span-5 flex items-center gap-2">
                    <div className="h-3 w-24 bg-bone-200" />
                    <span className="label-stencil !text-[9px] !text-spark">
                      PENDING
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- SPONSOR BAND ----------------------------- */

function SponsorBand() {
  return (
    <section className="relative border-b border-ink-900/10 bg-bone-50">
      <div className="mx-auto max-w-[1400px] px-5 py-16 sm:px-8 lg:px-12 lg:py-20">
        <div className="flex flex-col items-start gap-6 border-l-4 border-spark pl-6 sm:flex-row sm:items-center sm:justify-between sm:gap-8">
          <div>
            <div className="label-stencil text-ink-500 mb-2">05 / Sponsors</div>
            <h2 className="font-display text-2xl leading-tight tracking-tight sm:text-3xl">
              Robotics is not cheap.{" "}
              <span className="text-spark">Meet the sponsors</span> backing a
              community team on the world stage.
            </h2>
          </div>
          <a
            href="#/sponsors"
            className="shrink-0 inline-flex items-center gap-3 border-2 border-ink-900 bg-bone-50 px-5 py-3 font-mono text-xs font-semibold uppercase tracking-wider text-ink-900 hover:bg-ink-900 hover:text-bone-50 transition-colors"
          >
            View sponsors
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
              <path d="M1 6h10M7 2l4 4-4 4" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------- CONTACT CTA ----------------------------- */

function ContactCTA() {
  return (
    <section id="contact-cta" className="relative overflow-hidden bg-bone-100/60">
      <div className="grid-bg-fine absolute inset-0 opacity-70" aria-hidden />
      <div className="relative mx-auto max-w-[1400px] px-5 py-20 sm:px-8 sm:py-28 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-3xl text-center">
          <div className="label-stencil text-spark mb-6">
            <span className="inline-block h-px w-6 bg-spark align-middle" /> 06 / Get in touch{" "}
            <span className="inline-block h-px w-6 bg-spark align-middle" />
          </div>
          <h2 className="font-display text-[clamp(2.2rem,6vw,4.5rem)] leading-[0.95] tracking-tight text-ink-900">
            Want to back a team that builds, breaks,{" "}
            <em className="not-italic text-spark">and ships</em>?
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-[15px] leading-relaxed text-ink-600">
            Sponsorships, mentoring, media inquiries, or just to say hi — our
            inbox is open and we reply faster than our autonomous period.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
            <a
              href="mailto:contact@findtheta.org"
              className="inline-flex items-center gap-3 bg-ink-900 px-6 py-3.5 font-mono text-xs font-semibold uppercase tracking-wider text-bone-50 hover:bg-spark transition-colors"
            >
              contact@findtheta.org
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden>
                <path d="M2 12L12 2M12 2H4M12 2v8" stroke="currentColor" strokeWidth="1.75" strokeLinecap="square" />
              </svg>
            </a>
            <a
              href="#/sponsors"
              className="inline-flex items-center gap-3 border border-ink-900/20 bg-bone-50 px-6 py-3.5 font-mono text-xs font-semibold uppercase tracking-wider text-ink-900 hover:border-ink-900 transition-colors"
            >
              Sponsorship prospectus
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
