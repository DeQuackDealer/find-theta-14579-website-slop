import { useEffect, useRef, useState } from 'react';
import { cn } from '../utils/cn';
import {
  Arrow,
  Ibis,
  Target,
  Cog,
  Wrench,
  Chip,
  Trophy,
  Robot,
  Image as ImageIcon,
  News,
  Bolt,
} from '../components/Icons';

type HomeProps = {
  onNavigate: (path: string) => void;
};

const stats = [
  { value: '0', suffix: '+', label: 'Awards & honours', note: 'early days' },
  { value: '0', suffix: '+', label: 'Members & alumni', note: 'growing roster' },
  { value: '0', suffix: '', label: 'World championships', note: 'first, target set' },
  { value: '0', suffix: '%', label: 'Qualification rate', note: 'first season pending' },
];

const capabilities = [
  { icon: Cog, title: 'Design', desc: 'Iterating mechanisms in CAD, from prototype to competition-ready.' },
  { icon: Wrench, title: 'Fabrication', desc: 'Machining, 3D printing, and assembling every part in-house.' },
  { icon: Chip, title: 'Programming', desc: 'Writing autonomous routines, teleop controls, and sensor fusion.' },
  { icon: Target, title: 'Strategy', desc: 'Analysing the field, scouting opponents, adapting match to match.' },
];

export function Home({ onNavigate }: HomeProps) {
  const [time, setTime] = useState(new Date());
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const timeStr = time.toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div className="relative">
      {/* HERO */}
      <section
        ref={heroRef}
        className="relative min-h-[100svh] flex flex-col noise overflow-hidden border-b border-line"
      >
        <div className="absolute inset-0 grid-bg opacity-50 pointer-events-none" />
        <div
          className="absolute inset-0 pointer-events-none opacity-80"
          style={{
            backgroundImage:
              'radial-gradient(circle at 70% 60%, rgba(255,107,26,0.22), transparent 45%), radial-gradient(circle at 15% 20%, rgba(0,229,199,0.08), transparent 40%)',
          }}
        />

        <div className="relative flex-1 flex flex-col max-w-[1400px] mx-auto w-full px-5 md:px-8 pt-28 md:pt-36 pb-10 md:pb-16">
          {/* Top status row */}
          <div className="flex items-start justify-between mb-auto gap-4">
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-3 font-mono text-[10px] md:text-[11px] uppercase tracking-[0.22em] text-ash">
                <span className="inline-flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-signal animate-[pulseDot_2s_ease-in-out_infinite]" />
                  SYS.STATUS: ONLINE
                </span>
              </div>
              <div className="font-mono text-[10px] md:text-[11px] text-ash/80 tracking-[0.2em] uppercase">
                TEAM_ID: <span className="text-chalk">FTC-14579</span>
              </div>
            </div>
            <div className="hidden sm:flex flex-col items-end gap-1 font-mono text-[10px] md:text-[11px] text-ash/80 uppercase tracking-[0.2em]">
              <div>SEASON: <span className="text-chalk">2025 / 2026</span></div>
              <div>LOCAL_TIME: <span className="text-chalk tabular-nums">{timeStr}</span></div>
            </div>
          </div>

          {/* Hero text */}
          <div className="mt-16 md:mt-20 mb-auto">
            <div className="font-mono text-[11px] md:text-xs uppercase tracking-[0.3em] text-amber mb-6 md:mb-8">
              // A student-run first tech challenge team
            </div>
            <h1 className="font-sans font-bold tracking-tighter leading-[0.86] text-[17vw] md:text-[14vw] lg:text-[13rem] text-chalk">
              FIND
              <span className="flex items-center gap-3 md:gap-6">
                <span className="text-amber">TH</span>
                <span className="relative inline-flex items-center justify-center">
                  <span
                    className="block w-[0.85em] h-[0.85em] rounded-full border-[0.035em] border-chalk/40 relative"
                    aria-hidden
                  >
                    <span className="absolute inset-[0.18em] rounded-full border-[0.025em] border-chalk" />
                    <span className="absolute left-1/2 top-0 bottom-0 w-px bg-chalk/60" />
                    <span className="absolute top-1/2 left-0 right-0 h-px bg-chalk/60" />
                    <span className="absolute inset-[0.42em] rounded-full bg-amber" />
                  </span>
                  <span className="text-stroke-amber">θ</span>
                </span>
                <span className="text-chalk">TA</span>
              </span>
            </h1>
            <div className="mt-8 md:mt-10 grid md:grid-cols-12 gap-6 md:gap-8 items-end">
              <p className="md:col-span-6 text-chalk/80 text-lg md:text-xl leading-relaxed max-w-xl">
                We design, build, and program competition robots — from bare chassis to
                match-ready machines — season after season, with the precision of the ibis.
              </p>
              <div className="md:col-span-4 md:col-start-9 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => onNavigate('/fleet')}
                  className="group inline-flex items-center justify-between gap-3 bg-chalk text-ink font-mono uppercase tracking-[0.15em] text-xs px-5 py-3.5 hover:bg-amber transition-colors"
                >
                  <span>Meet the fleet</span>
                  <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
                <button
                  onClick={() => onNavigate('/sponsors')}
                  className="group inline-flex items-center justify-between gap-3 border border-line text-chalk font-mono uppercase tracking-[0.15em] text-xs px-5 py-3.5 hover:border-amber hover:text-amber transition-colors"
                >
                  <span>Support us</span>
                  <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>
            </div>
          </div>

          {/* Bottom ticker */}
          <div className="mt-10 md:mt-16 border-t border-line pt-4 relative overflow-hidden">
            <div className="flex whitespace-nowrap animate-[marquee_30s_linear_infinite] font-mono text-[10px] md:text-[11px] uppercase tracking-[0.25em] text-ash/70">
              {Array.from({ length: 2 }).map((_, i) => (
                <span key={i} className="flex items-center gap-8 pr-8">
                  <span>◇ Build</span>
                  <span>◇ Test</span>
                  <span>◇ Break</span>
                  <span>◇ Iterate</span>
                  <span>◇ Compete</span>
                  <span>◇ <span className="text-amber">Learn faster</span></span>
                  <span>◇ Ship</span>
                  <span>◇ Find Theta</span>
                  <span>◇ FTC 14579</span>
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PHILOSOPHY */}
      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-20 md:py-28 grid lg:grid-cols-12 gap-10 lg:gap-16">
          <div className="lg:col-span-5">
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-5 flex items-center gap-3">
              <span className="inline-block w-6 h-px bg-amber" />
              01 / Philosophy
            </div>
            <h2 className="font-sans text-3xl md:text-5xl font-semibold tracking-tight text-chalk leading-[1.08]">
              Different faces every season.
              <br />
              <em className="text-ash not-italic font-normal">The same core approach.</em>
            </h2>
          </div>

          <div className="lg:col-span-7 space-y-6 md:space-y-8">
            <p className="text-chalk/85 text-lg md:text-xl leading-relaxed">
              Find Theta is a student-led FIRST Tech Challenge team competing as team 14579.
              Every season we start with a blank slate — new game, new rules, new problems —
              and we build our answer from scratch.
            </p>
            <p className="text-ash text-base md:text-lg leading-relaxed">
              We watch the ibis for a reason: a bird that thrives by staying sharp-eyed and adaptable,
              never boxed in by a single habitat. That's the standard we hold our engineering to.
              We don't chase one ideal robot. We chase a team that can build the <em className="text-chalk not-italic font-medium">right</em> robot,
              every single year.
            </p>

            <div className="pt-4 grid grid-cols-2 gap-px bg-line border border-line">
              {capabilities.map((c, i) => {
                const Icon = c.icon;
                return (
                  <div
                    key={i}
                    className="bg-ink p-5 md:p-6 group hover:bg-ink-2 transition-colors"
                  >
                    <Icon className="w-6 h-6 text-amber mb-3" />
                    <div className="font-sans text-chalk font-medium text-base md:text-lg mb-1">{c.title}</div>
                    <div className="text-ash text-sm leading-relaxed">{c.desc}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* IMAGE + STATS */}
      <section className="relative border-b border-line bg-ink-2">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-16 md:py-20">
          <div className="grid md:grid-cols-12 gap-6 md:gap-8 mb-10">
            <div className="md:col-span-7 relative aspect-[16/10] overflow-hidden border border-line group">
              <img
                src="/images/hero.jpg"
                alt="A Find Theta competition robot on the field"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5 md:p-6 flex items-end justify-between gap-4">
                <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-chalk">
                  <div className="text-ash/80">Subject</div>
                  <div>Competition chassis · mockup</div>
                </div>
                <Ibis className="w-10 h-10 text-amber" />
              </div>
              <div className="absolute top-4 left-4 font-mono text-[10px] uppercase tracking-[0.2em] text-chalk/80 bg-ink/70 backdrop-blur px-2 py-1 border border-line">
                REC · 001
              </div>
            </div>
            <div className="md:col-span-5 relative aspect-[16/10] md:aspect-auto overflow-hidden border border-line group">
              <img
                src="/images/build.jpg"
                alt="Hands assembling a robot on the workbench"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-5 md:p-6">
                <div className="font-mono text-[10px] uppercase tracking-[0.2em] text-chalk">
                  <div className="text-ash/80">Subject</div>
                  <div>Build bench · in progress</div>
                </div>
              </div>
              <div className="absolute top-4 left-4 font-mono text-[10px] uppercase tracking-[0.2em] text-chalk/80 bg-ink/70 backdrop-blur px-2 py-1 border border-line">
                REC · 002
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 border-t border-b border-line">
            {stats.map((s, i) => (
              <div
                key={i}
                className={cn(
                  'relative p-5 md:p-7 flex flex-col',
                  i < 2 && 'border-b lg:border-b-0 border-line',
                  i % 2 === 0 && 'border-r border-line',
                  i < 3 && 'lg:border-r'
                )}
              >
                <div className="flex items-baseline gap-0.5">
                  <span className="font-sans font-semibold text-5xl md:text-6xl tracking-tighter text-chalk tabular-nums leading-none">
                    {s.value}
                  </span>
                  <span className="font-sans text-2xl md:text-3xl text-amber font-medium leading-none">
                    {s.suffix}
                  </span>
                </div>
                <div className="mt-3 font-mono text-[10px] uppercase tracking-[0.2em] text-ash">
                  {s.label}
                </div>
                <div className="mt-1 text-xs text-ash/70 font-mono">{s.note}</div>
                <div className="absolute top-3 right-3 font-mono text-[9px] text-line tracking-wider">
                  0{i + 1}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FULL WIDTH BANNER QUOTE */}
      <section className="relative border-b border-line overflow-hidden">
        <div className="relative">
          <img
            src="/images/competition.jpg"
            alt="Competition field ready for a match"
            className="w-full h-[60vh] md:h-[75vh] object-cover opacity-50"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-ink/50 via-ink/30 to-ink" />
          <div className="absolute inset-0 grid-bg opacity-40 pointer-events-none" />
        </div>
        <div className="absolute inset-0 flex items-end">
          <div className="max-w-[1400px] mx-auto w-full px-5 md:px-8 pb-12 md:pb-20">
            <div className="max-w-4xl">
              <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-4 flex items-center gap-3">
                <Bolt className="w-3.5 h-3.5" />
                On the field
              </div>
              <h2 className="font-sans font-semibold text-4xl md:text-6xl lg:text-7xl tracking-tight leading-[1.02] text-chalk">
                Every match is a chance
                <br />
                to <em className="text-amber not-italic">learn faster.</em>
              </h2>
            </div>
          </div>
        </div>
      </section>

      {/* HONOURS */}
      <section className="relative border-b border-line bg-ink-2">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-20 md:py-28 grid md:grid-cols-12 gap-10 items-start">
          <div className="md:col-span-5">
            <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-5 flex items-center gap-3">
              <Trophy className="w-3.5 h-3.5" />
              02 / Record book
            </div>
            <h2 className="font-sans text-3xl md:text-5xl font-semibold tracking-tight text-chalk leading-[1.05]">
              Honours
            </h2>
            <p className="mt-5 text-ash text-base md:text-lg leading-relaxed max-w-md">
              We're still writing our first entry. Results will appear here as the season unfolds.
            </p>
          </div>
          <div className="md:col-span-7 relative border border-line bg-ink p-8 md:p-12">
            <span className="corner-ticks absolute inset-0 pointer-events-none" />
            <div className="flex items-center gap-3 mb-6">
              <span className="w-2 h-2 bg-amber animate-[pulseDot_2s_ease-in-out_infinite]" />
              <span className="font-mono text-[10px] text-ash tracking-[0.2em] uppercase">
                Awaiting first result — placeholder log
              </span>
            </div>
            <div className="flex items-baseline gap-4 mb-6">
              <span className="font-sans font-semibold text-7xl md:text-8xl text-stroke leading-none tabular-nums">0</span>
              <span className="font-sans font-medium text-2xl text-chalk">honours earned so far.</span>
            </div>
            <p className="text-ash leading-relaxed max-w-lg">
              Our first honours are still ahead of us. Check back after the next competition —
              or <button onClick={() => onNavigate('/sponsors')} className="text-amber underline underline-offset-4 hover:text-chalk transition-colors">help us get there faster.</button>
            </p>
          </div>
        </div>
      </section>

      {/* EXPLORE OTHER PAGES */}
      <section className="relative border-b border-line">
        <div className="max-w-[1400px] mx-auto px-5 md:px-8 py-20 md:py-28">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10 md:mb-14">
            <div>
              <div className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber mb-4">
                03 / Explore
              </div>
              <h2 className="font-sans text-3xl md:text-5xl font-semibold tracking-tight text-chalk leading-[1.05]">
                The rest of the shop.
              </h2>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-px bg-line border border-line">
            {[
              {
                icon: Robot,
                tag: 'Fleet',
                title: 'Our robots',
                desc: 'Every Find Theta machine, season by season — CAD, specs, and stories from the build room.',
                path: '/fleet',
              },
              {
                icon: ImageIcon,
                tag: 'Gallery',
                title: 'Moments',
                desc: 'Photographs from the pits, the field, and the long nights in between.',
                path: '/gallery',
              },
              {
                icon: News,
                tag: 'Updates',
                title: 'Field notes',
                desc: 'Build logs, post-mortems, and dispatches from the season.',
                path: '/updates',
              },
            ].map((c, i) => {
              const Icon = c.icon;
              return (
                <button
                  key={i}
                  onClick={() => onNavigate(c.path)}
                  className="group relative bg-ink p-6 md:p-8 text-left hover:bg-ink-2 transition-colors"
                >
                  <div className="flex items-start justify-between mb-8">
                    <Icon className="w-7 h-7 text-amber" />
                    <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-ash">
                      0{i + 1}
                    </span>
                  </div>
                  <div className="font-mono text-[11px] uppercase tracking-[0.2em] text-ash mb-2">
                    {c.tag}
                  </div>
                  <h3 className="font-sans text-2xl md:text-3xl font-semibold text-chalk tracking-tight mb-3">
                    {c.title}
                  </h3>
                  <p className="text-ash leading-relaxed text-sm md:text-base mb-6">
                    {c.desc}
                  </p>
                  <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] text-chalk group-hover:text-amber transition-colors">
                    Enter
                    <Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
