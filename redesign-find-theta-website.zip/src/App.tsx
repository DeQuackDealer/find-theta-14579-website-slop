import { useEffect, useState } from 'react';
import { Nav } from './components/Nav';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Fleet } from './pages/Fleet';
import { Gallery } from './pages/Gallery';
import { Updates } from './pages/Updates';
import { Sponsors } from './pages/Sponsors';

function getPathFromHash(): string {
  const hash = window.location.hash.replace(/^#/, '');
  if (!hash || hash === '/') return '/';
  return hash.startsWith('/') ? hash : '/' + hash;
}

export default function App() {
  const [path, setPath] = useState<string>(() => {
    if (typeof window !== 'undefined') return getPathFromHash();
    return '/';
  });

  useEffect(() => {
    const onHashChange = () => setPath(getPathFromHash());
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (to: string) => {
    window.location.hash = to === '/' ? '/' : to;
    setPath(to);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  let page: React.ReactNode;
  switch (path) {
    case '/fleet':
      page = <Fleet onNavigate={navigate} />;
      break;
    case '/gallery':
      page = <Gallery onNavigate={navigate} />;
      break;
    case '/updates':
      page = <Updates onNavigate={navigate} />;
      break;
    case '/sponsors':
      page = <Sponsors />;
      break;
    case '/':
    default:
      page = <Home onNavigate={navigate} />;
      break;
  }

  return (
    <div className="min-h-screen bg-ink text-chalk flex flex-col">
      <Nav currentPath={path} onNavigate={navigate} />
      <main key={path} className="flex-1 animate-[rise_0.5s_cubic-bezier(0.22,1,0.36,1)_both]">
        {page}
      </main>
      <Footer onNavigate={navigate} />
    </div>
  );
}
