import { useEffect, useState } from "react";
import Nav from "./components/Nav";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Fleet from "./pages/Fleet";
import Gallery from "./pages/Gallery";
import Updates from "./pages/Updates";
import Sponsors from "./pages/Sponsors";

type Route = "home" | "fleet" | "gallery" | "updates" | "sponsors";

function parseHash(): Route {
  // Strip leading #/ and any anchor fragment (#contact), take the first path segment
  const h = window.location.hash
    .replace(/^#\/?/, "")
    .split("#")[0]
    .split("/")[0];
  if (h === "fleet") return "fleet";
  if (h === "gallery") return "gallery";
  if (h === "updates") return "updates";
  if (h === "sponsors") return "sponsors";
  return "home";
}

export default function App() {
  const [route, setRoute] = useState<Route>(parseHash());

  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    // Check for an in-page anchor (e.g. #/sponsors#contact)
    const hash = window.location.hash;
    const anchorMatch = hash.match(/#([^/]+)$/);
    if (anchorMatch && anchorMatch[1]) {
      // Wait for render, then scroll to anchor
      requestAnimationFrame(() => {
        const el = document.getElementById(anchorMatch[1]);
        if (el) {
          el.scrollIntoView({ behavior: "smooth", block: "start" });
          return;
        }
        window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      });
    } else {
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
    }
  }, [route]);

  return (
    <div className="min-h-screen flex flex-col bg-bone-50 text-ink-900">
      <Nav current={route} />
      <main className="flex-1">
        {route === "home" && <Home />}
        {route === "fleet" && <Fleet />}
        {route === "gallery" && <Gallery />}
        {route === "updates" && <Updates />}
        {route === "sponsors" && <Sponsors />}
      </main>
      <Footer />
    </div>
  );
}
